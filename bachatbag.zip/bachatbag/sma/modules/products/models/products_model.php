<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/*
| -----------------------------------------------------
| PRODUCT NAME: 	STOCK MANAGER ADVANCE 
| -----------------------------------------------------
| AUTHER:			MIAN SALEEM 
| -----------------------------------------------------
| EMAIL:			saleem@tecdiary.com 
| -----------------------------------------------------
| COPYRIGHTS:		RESERVED BY TECDIARY IT SOLUTIONS
| -----------------------------------------------------
| WEBSITE:			http://tecdiary.net
| -----------------------------------------------------
|
| MODULE: 			Products
| -----------------------------------------------------
| This is products module model file.
| -----------------------------------------------------
*/


class Products_model extends CI_Model
{
	
	
	public function __construct()
	{
		parent::__construct();

	}
	
	public function getAllProducts() 
	{
		$q = $this->db->get('products');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	
	public function getAllCatalog() 
	{
		$q = $this->db->get('catalog');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	public function getAllcity(){
		
		$q = $this->db->get('city');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	public function getProductfeatureByID($code) 
	{

		$q = $this->db->query("SELECT pf.description_header,pf.details,pf.images FROM product_feature as pf  WHERE pf.product_code='".$code ."'  and (pf.description_header!='' and pf.description_header!='<br>' or pf.details!='')");
		 if($q->num_rows() > 0) {
			//print_r($q->result_array());
			return $q->result_array();
		}
		  return FALSE;

	}
	
	public function getProductfeaturespecificationByID($code) 
	{

		$q = $this->db->query("SELECT pf.header as headerval,pf.name,pf.value FROM product_feature as pf  WHERE pf.product_code='".$code ."' and pf.header!='' ");
		 if($q->num_rows() > 0) {
				return $q->result_array();
		}
		  return FALSE;

	}
	public function getProductByID($id) 
	{

		$q = $this->db->get_where('products', array('code' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	public function getProductpricebcityByID($id){
		$q = $this->db->query("SELECT city ,product_mrp,price FROM products WHERE code='".$id ."'  ");
		 if($q->num_rows() > 0) {
				return $q->result_array();
		}
		  return FALSE;
	}
	public function getproduct_rate($id){
		
		$q = $this->db->query("SELECT product_ratings.*,users.first_name FROM `product_ratings` LEFT JOIN users on users.id=product_ratings.user_id WHERE `product_code`=".$id." ");
		
		
				return $q->result_array();
	
	
		
	}
	public function getproduct_image($code) 
	{

		$q = $this->db->query('select * from product_image where product_code="'.$code.'" '); 
	return $q->result_array();

	}
	
	public function getproduct_features_image($code) 
	{

		$q = $this->db->query('select * from product_feature where product_code="'.$code.'" and images!="" '); 
	return $q->result_array();

	}
	
	public function getProductByCategoryID($id) 
	{

		$q = $this->db->get_where('products', array('category_id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return true;
		  } 
		
		  return FALSE;

	}
	
	public function getAllTaxRates() 
	{
		$q = $this->db->get('tax_rates');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getProductsByCode($code) 
	{
		$q = $this->db->query("SELECT * FROM products WHERE code LIKE '%{$code}%' ORDER BY code");
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
		
		 public function getproductimagesByID($id){
			//print_r($id);
			//exit;
			$q = $this->db->query("SELECT * FROM product_image  WHERE product_code='".$id."' ");
	//	print_r($q->result_array());
			return $q->result_array();
		} 
		
		
		public function getProductcategoryByID($id){
			
			$q = $this->db->query("SELECT category_id,subcategory_id FROM products  WHERE code='".$id."' ");
		//print_r($q->result_array());
			return $q->result_array();
		}
	public function getProductQuantity($product_id, $warehouse = DEFAULT_WAREHOUSE) 
	{
		$q = $this->db->get_where('warehouses_products', array('product_id' => $product_id, 'warehouse_id' => $warehouse), 1); 
		
		  if( $q->num_rows() > 0 )
		  {
			return $q->row_array(); //$q->row();
		  } 
		
		  return FALSE;
		
	}
	public function getproduct_cate($code){
		
		$q = $this->db->query("select p.*,c.name as catname,sb.name as subname from products as p left join categories as c on p.category_id=c.id left join subcategories as sb on sb.id=p.subcategory_id where p.code='".$code."'"); 
		
		  if( $q->num_rows() > 0 )
		  {
			return $q->result_array(); //$q->row();
		  } 
		
		  return FALSE;
	}
	public function getAllWarehouses() 
	{
		$q = $this->db->get('warehouses');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getWarehouseByID($id) 
	{

		$q = $this->db->get_where('warehouses', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function getProductByCode($code) 
	{
			
		$q = $this->db->get_where('products', array('code' => $code), 1); 
		
		  if( $q->num_rows() > 0 )
		  {
			
			return $q->row();
		  } 
			return FALSE;
	}
	
		public function addProduct($code, $name,   $data = array(),$datanew = array(),$datanew1 = array(),$datanew2 = array())
	{
		//print_r($data);
		
			// Product data
			$addOn = array('code'	     			=> $data['code'],
				'name'   				=> $data['product_name'],
				'companyname'   		=> $data['companyname'],
				'catalog_id'            => $data['catalog_id'],
				'unit' 					=> $data['unit'],
				'cost'	     			=> $data['cost'],
				'name_hindi'	     			=> $data['name_hindi'],
				'max_quantity'	     			=> $data['max_quantity'],
				'min_quantity'	     			=> $data['min_quantity'],
				'alert_quantity'   		=> $data['alert_quantity'],
				'tax_rate'   			=> $data['tax_rate'],
				'track_quantity'   		=> $data['track_quantity'],
				'cf1'   					=> $data['cf1'],
				'cf2'   					=> $data['cf2'],
				'cf3'   					=> $data['cf3'],
				'cf4'   					=> $data['cf4'],
				'cf5'   					=> $data['cf5'],
				'cf6'   					=> $data['cf6'],
                'details'   				=> $data['details'],
				'display_in_client_side'	=> $data['display_in_client_side'],
				'related_product' => $data['related_product'],
				'daily_deals' => $data['daily_deals'],
				'feature_product' =>$data['feature_product'],
				'new_products' => $data['new_products'],
				'best_seller' => $data['best_seller'],
				'cross_seller' => $data['cross_seller'],
				'up_seller' => $data['up_seller'],
				'session_id'				=>$data['session_id'],
				'out_of_stock'				=>$data['out_of_stock'],
				'reward_points'				=>$data['reward_points'],
				'reward_points_value'				=>$data['reward_points_value']
				
				
								);
						end($addOn);
						foreach ( $datanew2 as &$var ) {
						$var = array_merge($addOn, $var);								
					}
			//print_r($datanew2);
		
//echo"ghg";
		if($this->db->insert_batch('products', $datanew2)) {
			//$product_id = $this->db->insert_id();	
						
				$addOn = array('product_code'	 => $data['code']
								);
						end($addOn);
						foreach ( $datanew as &$var ) {
						$var = array_merge($addOn, $var);								
					}
//print_r($datanew);
				if(	$this->db->insert_batch('product_feature', $datanew))
				{	
					
					$addOn = array('product_code'	 => $data['code']
			
								);
						end($addOn);
						foreach ( $datanew1 as &$var ) {
						$var = array_merge($addOn, $var);								
					}
		
					if(	$this->db->insert_batch('product_image', $datanew1))
					{		
					
					return true;
		} else {
		
			return false;
					}
		
	}
		}
	}
	
	
	
	
	

	public function add_products($data = array())
	{
		//print_r($data);
		if($this->db->insert_batch('products', $data)) {
			
			return true;
		} else {
			return false;
		}
	}
	
	public function add_products_feature($data = array())
	{
		//print_r($data);
		if($this->db->insert_batch('product_feature', $data)) {
			
			return true;
		} else {
			return false;
		}
	}
	public function updatePrice($data = array())
	{
		
		if($this->db->update_batch('products', $data, 'code')) {
			return true;
		} else {
			return false;
		}
	}
	
	public function updateProduct($id,$code, $name,  $photo, $data = array(),$datanew = array(),$datanew1 =array(),$datanew2 = array())
	{
		//print_r($data);
		$addOn = array('code'	     			=> $data['code'],
				'name'   				=> $data['name'],
				'companyname'   		=> $data['companyname'],
				'catalog_id'            => $data['catalog_id'],
				'unit' 					=> $data['unit'],
				'cost'	     			=> $data['cost'],
				'name_hindi'	     			=> $data['name_hindi'],
				'max_quantity'	     			=> $data['max_quantity'],
				'min_quantity'	     			=> $data['min_quantity'],
				'alert_quantity'   		=> $data['alert_quantity'],
				'tax_rate'   			=> $data['tax_rate'],
				'track_quantity'   		=> $data['track_quantity'],
				'cf1'   					=> $data['cf1'],
				'cf2'   					=> $data['cf2'],
				'cf3'   					=> $data['cf3'],
				'cf4'   					=> $data['cf4'],
				'cf5'   					=> $data['cf5'],
				'cf6'   					=> $data['cf6'],
                'details'   				=> $data['details'],
				'display_in_client_side'	=> $data['display_in_client_side'],
				'related_product' => $data['related_product'],
				'daily_deals' => $data['daily_deals'],
				'feature_product' =>$data['feature_product'],
				'new_products' => $data['new_products'],
				'best_seller' => $data['best_seller'],
				'cross_seller' => $data['cross_seller'],
				'up_seller' => $data['up_seller'],
				'session_id'				=>$data['session_id'],
				'out_of_stock'				=>$data['out_of_stock'],
						'reward_points'				=>$data['reward_points'],
				'reward_points_value'				=>$data['reward_points_value']
				

								);
						end($addOn);
						foreach ( $datanew2 as &$var ) {
						$var = array_merge($addOn, $var);								
					}
			//print_r($datanew2);
		
//echo"ghg";
	if($this->db->delete('products', array('code' => $code))) {
			
		if($this->db->insert_batch('products', $datanew2)) {
			
				
				
				$addOn = array('product_code'	 => $data['code']
			
								);
						end($addOn);
						foreach ( $datanew as &$var ) {
						$var = array_merge($addOn, $var);								
					}
					
					//print_r($datanew);
				if($this->db->delete('product_feature', array('product_code' => $code))) {
			
		
				if(	$this->db->insert_batch('product_feature', $datanew))
				{
					
					foreach ($array as $key => $value1) {
						foreach($value1 as $key =>$value){
    $value1 = trim($value);
   
}
					}
					
					 if (!empty($value))
					 {
				if($this->db->delete('product_image', array('product_code' => $code))) {
					
	$addOn = array('product_code'	 => $data['code']
			
								);
						end($addOn);
						foreach ( $datanew1 as &$var ) {
						$var = array_merge($addOn, $var);								
					}
		
					if(	$this->db->insert_batch('product_image', $datanew1))
					{		
			return true;
		}
			 else {
			return false;
		}
				}
			}else{
				return true;
			}
				}
		}
		}
	}
	}
	
	public function deleteProduct($id) 
	{
		if($this->db->delete('products', array('code' => $id)) && $this->db->delete('warehouses_products', array('product_id' => $id)) ) {
			return true;
		}
	return FALSE;
	}
	
	
	
	public function getAllCategories() 
	{
		$q = $this->db->get('categories');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function totalCategoryProducts($category_id) 
	{
		$q = $this->db->get_where('products', array('category_id' => $category_id));
				
			return $q->num_rows();
		
	}
	
	public function getCategoryByID($id) 
	{
		$q = $this->db->get_where('categories', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function getCategoryByCode($code) 
	{
		
		$q = $this->db->get_where('categories', array('code' => $code), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
        
		public function getsubByCode($code) 
	{
		
		$q = $this->db->get_where('subcategories', array('code' => $code), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
		public function getcatalogByCode($code) 
	{
		//print_r($code);
		$q = $this->db->get_where('catalog', array('code' => $code), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
        public function getTaxRateByName($name) 
	{
		$q = $this->db->get_where('tax_rates', array('name' => $name), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	
	public function getSubCategoriesByCategoryID($category_id) 
	{
		//print_r($category_id);
		$q=$this->db->query("select * from subcategories WHERE category_id IN ($category_id)");
		//$q = $this->db->get_where("subcategories", array('category_id' => $category_id));
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
		
		return FALSE;
	}
	
	public function getDamagePdByID($id) 
	{

		$q = $this->db->get_where('damage_products', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function addDamage($product_id, $date, $quantity, $warehouse, $note)
	{
		
		if($wh_qty_details = $this->getProductQuantity($product_id, $warehouse)) {
			$balance_qty = $wh_qty_details['quantity'] - $quantity;
			$this->updateQuantity($product_id, $warehouse, $balance_qty);
		} else {
			$balance_qty = 0 - $quantity;
			$this->insertQuantity($product_id, $warehouse, $balance_qty);
		}
                $prd = $this->getProductByID($product_id);
                $nQTY = $prd->quantity - $quantity;
		
		$data = array(
				'date'	     		=> $date,
				'product_id'   			=> $product_id,
				'quantity'   			=> $quantity,
				'warehouse_id'   		=> $warehouse,
				'note'   			=> $note,
				'user'				=> USER_NAME
			);
			
		if($this->db->insert('damage_products', $data) && $this->db->update('products', array('quantity' => $nQTY), array('id' => $product_id))) {
			return true;
		} else {
			return false;
		}
	}
	
	public function updateDamage($id, $product_id, $date, $quantity, $warehouse, $note)
	{
		
		$wh_qty_details = $this->getProductQuantity($product_id, $warehouse);
		$dp_details = $this->getDamagePdByID($id);
		$old_quantity = $wh_qty_details['quantity'] + $dp_details->quantity;
		$balance_qty = $old_quantity - $quantity;
                $prd = $this->getProductByID($product_id);
                $nQTY = ($prd->quantity + $dp_details->quantity)- $quantity;
		
		$data = array(
				'date'	     		=> $date,
				'product_id'   			=> $product_id,
				'quantity'   			=> $quantity,
				'warehouse_id'   		=> $warehouse,
				'note'   				=> $note,
				'user'				=> USER_NAME
			);
			
		if($this->db->update('damage_products', $data, array('id' => $id)) && $this->updateQuantity($product_id, $warehouse, $balance_qty) && $this->db->update('products', array('quantity' => $nQTY), array('id' => $product_id))) {
			return true;
		} else {
			return false;
		}
	}
	
	public function insertQuantity($product_id, $warehouse_id, $quantity)
	{	

			// Product data
			$productData = array(
				'product_id'	     		=> $product_id,
				'warehouse_id'   			=> $warehouse_id,
				'quantity' 					=> $quantity
			);

		if($this->db->insert('warehouses_products', $productData)) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public function updateQuantity($product_id, $warehouse_id, $quantity)
	{	

			$productData = array(
				'quantity'	     			=> $quantity
			);
		
		if($this->db->update('warehouses_products', $productData, array('product_id' => $product_id, 'warehouse_id' => $warehouse_id))) {
			return true;
		} else {
			return false;
		}
	}
	
	public function deleteDamage($id)
	{
	
		if($this->db->delete('damage_products', array('id' => $id))) {
			return true;
		}
		
	return false;
	}
        
    public function products_count($category_id) {
        if($category_id) {
            $this->db->where('category_id', $category_id);
        }
        $this->db->from('products');
        return $this->db->count_all_results();
    }

    public function fetch_products($category_id, $limit, $start) {
	$this->db->select('name, code');
        $this->db->limit($limit, $start);
        if($category_id) {
            $this->db->where('category_id', $category_id);
        }
	$this->db->order_by("id", "asc"); 
        $query = $this->db->get("products");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
	
	
}
