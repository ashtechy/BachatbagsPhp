<script src="<?php echo $this->config->base_url(); ?>assets/js/validation.js"></script>
<script type="text/javascript">
$(function() {
	$('form').form();
});
</script>

<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>


	<h3 class="title"><?php echo $page_title; ?></h3>
	<p><?php echo $this->lang->line("enter_info"); ?></p>

   	<?php $attrib = array('class' => 'form-horizontal'); echo form_open("module=billers&view=add", $attrib);?>

<div class="control-group">
  <label class="control-label" for="name"><?php echo $this->lang->line("name"); ?></label>
  <div class="controls"> <?php echo form_input($name, '', 'class="span4" id="name" pattern=".{2,55}" required="required" data-error="'.$this->lang->line("name").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("phone"); ?></label>
  <div class="controls"> <input type="tel" name="phone" class="span4" pattern="[0-9]{7,15}" required="required" data-error="<?php echo $this->lang->line("phone").' '.$this->lang->line("is_required"); ?>" />
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="email_address"><?php echo $this->lang->line("email_address"); ?></label>
  <div class="controls"> <input type="email" name="email" class="span4"  data-error="<?php echo $this->lang->line("email_address"); ?>" />
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="company"><?php echo $this->lang->line("company"); ?></label>
  <div class="controls"> <?php echo form_input($company, '', 'class="span4 tip" title="'.$this->lang->line("bypass").'" id="company" pattern=".{1,55}"  data-error="'.$this->lang->line("company").' "');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="address"><?php echo $this->lang->line("address"); ?></label>
  <div class="controls"> <?php echo form_input($address, '', 'class="span4" id="address" pattern=".{2,255}"  data-error="'.$this->lang->line("address").' "');?>
  </div>
</div>  
<div class="control-group">
  <label class="control-label" for="city"><?php echo $this->lang->line("city"); ?></label>
  <div class="controls"> <?php echo form_input($city, '', 'class="span4" id="city" pattern=".{2,55}" data-error="'.$this->lang->line("city").'"');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="state"><?php echo $this->lang->line("state"); ?></label>
  <div class="controls"> <?php echo form_input($state, '', 'class="span4" id="state" pattern=".{2,55}"  data-error="'.$this->lang->line("state").' "');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("postal_code"); ?></label>
  <div class="controls"> <?php echo form_input($postal_code, '', 'class="span4" id="postal_code"pattern=".{4,8}"  data-error="'.$this->lang->line("postal_code").' "');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="country"><?php echo $this->lang->line("country"); ?></label>
  <div class="controls"> <?php echo form_input($country, '', 'class="span4" id="country" pattern=".{2,55}"  data-error="'.$this->lang->line("country").' "');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="country">Tin number</label>
  <div class="controls"> <?php echo form_input($tin_number, '', 'class="span4" id="tin_number"   data-error="'.$this->lang->line("tin_number").' "');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="country">Dl number</label>
  <div class="controls"> <?php echo form_input($dl_number, '', 'class="span4" id="dl_number"   data-error="'.$this->lang->line("dl_number").' "');?>
  </div>
</div>
 
<div class="control-group">
  <label class="control-label" for="country">Timings</label>
  <div class="controls"> <?php echo form_input($timings, '', 'class="span4" id="timings"   data-error="'.$this->lang->line("timings").' "');?>
  </div>
</div> 
<div class="control-group">
  <label class="control-label"><?php echo $this->lang->line("logo"); ?></label>
  <div class="controls">  
	  <?php 
	  $biller_logos[''] = ''; 
	  	foreach($logos as $key=>$value){
    		$biller_logos[$value] = $value;
		}
		echo form_dropdown('logo', $biller_logos, '', 'data-placeholder="'.$this->lang->line("select")." ".$this->lang->line("biller_logo").'"  data-error="'.$this->lang->line("biller_logo").' "'); ?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="cf6"><?php echo $this->lang->line("bcf6"); ?></label>
  <div class="controls"> <?php echo form_input('cf6', '', 'class="span4" id="cf6"');?>
  </div>
</div> 
<div class="control-group">
<label class="control-label" for="note"><?php echo $this->lang->line("invoice_footer"); ?></label>
  <div class="controls"> <?php echo form_textarea('invoice_footer', (isset($_POST['invoice_footer']) ? $_POST['invoice_footer'] : ""), 'class="input-block-level" id="note"');?> </div>
</div>
<div class="control-group">
  <div class="controls"> <?php echo form_submit('submit', $this->lang->line("add_biller"), 'class="btn btn-primary"');?> </div>
</div>
<?php echo form_close();?> 
   