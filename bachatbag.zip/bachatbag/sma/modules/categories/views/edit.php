<script src="<?php echo $this->config->base_url(); ?>assets/js/validation.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('form').form();
});
</script>
<link href="<?php echo $this->config->base_url(); ?>assets/css/bootstrap-fileupload.css" rel="stylesheet">

<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>


	<h3 class="title"><?php echo $page_title; ?></h3>
	<p><?php echo $this->lang->line("update_info"); ?></p>
    <?php $attrib = array('class' => 'form-horizontal'); echo form_open_multipart("module=categories&view=edit&id=".$id, $attrib);?>
 <div class="control-group">
  <label class="control-label" for="catalog"><?php echo $this->lang->line("catalog"); ?></label>
  <div class="controls">  <?php 
	  $cat2[''] = "";
	  	foreach($catalog as $cata) {
			//print_r($cata);
    		$cat2[$cata->id] = $cata->name;
		}
		echo form_dropdown('catalog', $cat2, $category->catalog_id, '  class="tip chzn-select span4" id="catalog" data-placeholder="'.$this->lang->line("select")." ".$this->lang->line("catalog").'"  required="required" data-error="'.$this->lang->line("catalog").' '.$this->lang->line("is_required").'"'); ?>

		</div>
		
		</div>
	
<?php// print_r($category); ?>
	
	<div class="control-group">
  <label class="control-label" for="code"><?php echo $this->lang->line("category_code"); ?></label>
  <div class="controls"> <?php echo form_input('code', $category->code, 'class="span4" id="code" required="required" pattern="[a-zA-Z0-9_-]{2,12}" data-error="'.$this->lang->line("code").' '.$this->lang->line("is_required").' '.$this->lang->line("min_2").'"');?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="name"><?php echo $this->lang->line("category_name"); ?></label>
  <div class="controls"> <?php echo form_input('name', $category->name, 'class="span4" id="name" required="required" data-error="'.$this->lang->line("name").' '.$this->lang->line("is_required").'"');?> </div>
</div>

<div class="control-group">
  <label class="control-label" for="product_image"><?php echo $this->lang->line("image"); ?></label>
  <div class="controls">
<div class="fileupload fileupload-new" data-provides="fileupload">
<span class="btn btn-file"><span class="fileupload-new"><?php echo $this->lang->line("select_image"); ?></span><span class="fileupload-exists"><?php echo $this->lang->line("change"); ?></span><input type="file" name="userfile" size="20" id="product_image" /></span>
<span class="fileupload-preview"></span>
<a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none">×</a>
</div>
  </div>
</div>




<div class="control-group">
<div class="col-sm-2" style="float:left;" > 
<label class="control-label" for="feature_product"><?php echo "Show in frontend catalog" ; ?></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <?php   
    $checked = "";
	//echo $category->front_catalog;
   if($category->front_catalog == 1){
	   
	   $checked = "checked";
   }
   else{
	   $checked = "";
   }

   $nav_checked = "";
   
   if($category->front_navi == 1){
	   
	   $nav_checked = "checked";
   }
   else{
	   $nav_checked = "";
   }
   
   
   ?>
	<input type="checkbox" value="1" name="front_end" class="form-control" id="front_end"   <?php echo $checked; ?> "/>
	
   </div>
</div>
<div class="control-group">
<div class="col-sm-2" style="float:left;" > 
<label class="control-label" for="feature_product"><?php echo "Show in Main Nav" ; ?></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <?php   
  
   $nav_checked = "";
   
   if($category->front_navi == 1){
	   
	   $nav_checked = "checked";
   }
   else{
	   $nav_checked = "";
   }
   
   
   ?>
	<input type="checkbox" value="1" name="front_navi" class="form-control" id="front_end"   <?php echo $nav_checked; ?> ">
	
   </div>
</div>
<div class="control-group">
  <div class="controls"> <?php echo form_submit('submit', $this->lang->line("update_category"), 'class="btn btn-primary"');?> </div>
</div>
<?php echo form_close();?> 