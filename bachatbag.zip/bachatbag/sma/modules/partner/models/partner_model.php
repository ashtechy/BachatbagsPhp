<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/*
| -----------------------------------------------------
| PRODUCT NAME: 	STOCK MANAGER ADVANCE 
| -----------------------------------------------------
| AUTHER:			MIAN SALEEM 
| -----------------------------------------------------
| EMAIL:			saleem@tecdiary.com 
| -----------------------------------------------------
| COPYRIGHTS:		RESERVED BY TECDIARY IT SOLUTIONS
| -----------------------------------------------------
| WEBSITE:			http://tecdiary.net
| -----------------------------------------------------
|
| MODULE: 			Partners
| -----------------------------------------------------
| This is partner module's model file.
| -----------------------------------------------------
*/


class partner_model extends CI_Model
{
	
	
	public function __construct()
	{
		parent::__construct();
				$this->load->config('auth/ion_auth', TRUE);


	}
	
	public function getAllPartners() 
	{
		$q = $this->db->get('partner');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function partner_count() {
        return $this->db->count_all("partner");
    }

    public function fetch_partner($limit, $start) {
        $this->db->limit($limit, $start);
		$this->db->order_by("id", "desc"); 
        $query = $this->db->get("partner");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
	
	public function getPartnerByID($id) 
	{

		$q = $this->db->get_where('partner', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function getPartnerByEmail($email) 
	{

		$q = $this->db->get_where('partner', array('email' => $email), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function addPartner($name, $email, $company, $data = array())
	{
		
		
		// Partner data
		$supplierData = array(
		    'name'	   			=> $data['name'],
		    'email'   				=> $data['email'],
		    'company'   			=> $data['company'],
		    'address' 				=> $data['address'],
			'latitude'      		=>$data['latitude'],
			'longitude'				=>$data['longitude'],
			'username'				=>$data['username'],
			'password'				=>$data['password'],
			'city'					=> $data['city'],
		    'state'  				=> $data['state'],
		    'postal_code' 		=> $data['postal_code'],
		    'country' 			=> $data['country'],
			'phone'	     		=> $data['phone'],
			'cf1'      			=> $data['cf1'],
			'cf2'      			=> $data['cf2'],
			'cf3'      			=> $data['cf3'],
			'cf4'      			=> $data['cf4'],
			'cf5'      			=> $data['cf5'],
			'cf6'      			=> $data['cf6']
		);

		if($this->db->insert('partner', $supplierData)) {
			return true;
		} else {
			return false;
		}
	}
	
		
	/* public function addPartnertousers($data1 = array())
	{
		
		$supplierDatauser = array(
				'email'   				=> $data1['email'],
		      'username'   				=> $data1['username'], 
			  'password'   				=> $data1['password']
		);
		if($this->db->insert('users', $supplierDatauser)) {
			return true;
		} else {
			return false;
		}
	} */
	
		
	public function updatePartner($id, $data = array())
	{
		
		
		// Supper data
		$supplierData = array(
		    'name'	   				=> $data['name'],
		    'email'   				=> $data['email'],
		    'company'   			=> $data['company'],
		    'address' 				=> $data['address'],
			'city'					=> $data['city'],
		    'state'  				=> $data['state'],
		    'postal_code' 			=> $data['postal_code'],
		    'country' 				=> $data['country'],
			'phone'	     			=> $data['phone'],
			'latitude'      		=>$data['latitude'],
			'longitude'				=>$data['longitude'],
			'username'				=>$data['username'],
			'password'				=>$data['password'],
			'cf1'      			=> $data['cf1'],
			'cf2'      			=> $data['cf2'],
			'cf3'      			=> $data['cf3'],
			'cf4'      			=> $data['cf4'],
			'cf5'      			=> $data['cf5'],
			'cf6'      			=> $data['cf6']
		);
		$this->db->where('id', $id);
		if($this->db->update('partner', $supplierData)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function add_partner($data = array())
	{
		
		if($this->db->insert_batch('partner', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function deletePartner($id) 
	{
		if($this->db->delete('partner', array('id' => $id))) {
			return true;
		}
	return FALSE;
	}

}
