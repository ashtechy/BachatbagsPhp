<script src="<?php echo $this->config->base_url(); ?>assets/js/validation.js"></script>
<script type="text/javascript">
$(function() {
	$('form').form();
});
</script>
 <script src="http://maps.google.com/maps/api/js?libraries=places&region=uk&language=en&sensor=true"></script>
                        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>


<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>


	<h3 class="title"><?php echo $page_title; ?></h3>
	<p><?php echo $this->lang->line("enter_info"); ?></p>

   	<?php $attrib = array('class' => 'form-horizontal'); echo form_open("module=customers&view=add", $attrib);?>

<div class="control-group">
  <label class="control-label" for="name"><?php echo $this->lang->line("name"); ?></label>
  <div class="controls"> <?php echo form_input($name, '', 'class="span4" id="name" pattern=".{2,55}" required="required" data-error="'.$this->lang->line("name").' '.$this->lang->line("is_required").'"');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("phone"); ?></label>
  <div class="controls"> <input type="tel" name="phone" class="span4" pattern="[0-9]{7,15}" required="required" data-error="<?php echo $this->lang->line("phone").' '.$this->lang->line("is_required"); ?>" />
  </div>
</div> 
<div class="control-group">
  <label class="control-label" for="email_address"><?php echo $this->lang->line("email_address"); ?></label>
  <div class="controls"> <input type="email" name="email" class="span4"  data-error="<?php echo $this->lang->line("email_address"); ?>" />
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="company"><?php echo $this->lang->line("company"); ?></label>
  <div class="controls"> <?php echo form_input($company, '', 'class="span4 tip" title="'.$this->lang->line("bypass").'" id="company" pattern=".{1,55}"  data-error="'.$this->lang->line("company").' "');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="country"><?php echo $this->lang->line("country"); ?></label>
  <div class="controls"> <?php echo form_input($country, '', 'class="span4" id="country" pattern=".{2,55}"  data-error="'.$this->lang->line("country").' "');?>
  </div>
</div> 

<div class="control-group">
  <label class="control-label" for="state"><?php echo $this->lang->line("state"); ?></label>
  <div class="controls"> <?php echo form_input($state, '', 'class="span4" id="state" pattern=".{2,55}"  data-error="'.$this->lang->line("state").' "');?>
  </div>
</div> 


<div class="control-group">
  <label class="control-label" for="city"><?php echo $this->lang->line("city"); ?></label>
  <div class="controls"> <?php echo form_input($city, '', 'class="span4" id="city" pattern=".{2,55}"  data-error="'.$this->lang->line("city").' "');?>
  </div>
</div>

<div class="control-group">
  <label class="control-label" for="address"><?php echo $this->lang->line("address"); ?></label>
  <div class="controls"> <input id="searchTextField" type="text" size="50" name="address" class="span4 " style="direction: ltr;">  </div>
 </div>
     <div class="controls">   <div id="map_canvas" style="height: 250px;width: 450px;margin: 0.6em;">
</div>
</div>  

<div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("latitude"); ?></label>
  <div class="controls"> <input type="text" id="MapLat" class="span4 boder MapLat"   name="latitude" placeholder="" required="">
 </div>
</div> 

<div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("longitude"); ?></label>
  <div class="controls"> <input type="text" id="MapLon"  class="span4 boder MapLon"   name="longitude" placeholder="" required="">
 </div>
</div> 

<div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("postal_code"); ?></label>
  <div class="controls"> <?php echo form_input($postal_code, '', 'class="span4" id="postal_code"pattern=".{4,8}"  data-error="'.$this->lang->line("postal_code").' "');?>
  </div>
</div> 

 <div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("username"); ?></label>
  <div class="controls"> <input type="text" id="username" class="span4 "   name="username" placeholder="" required="">
 </div>
</div> 

<div class="control-group">
  <label class="control-label" for="postal_code"><?php echo $this->lang->line("password"); ?></label>
  <div class="controls"> <input type="text" id="password" class="span4"   name="password" placeholder="" required="">
 </div>
</div> 
<div class="control-group">
  <div class="controls"> <?php echo form_submit('submit', $this->lang->line("add_customer"), 'class="btn btn-primary"');?> </div>
</div>
<?php echo form_close();?> 
    

	<script>
    $(function () {
        var lat = 40.8516701,
            lng = -93.2599318,
            latlng = new google.maps.LatLng(lat, lng),
            image = 'http://www.google.com/intl/en_us/mapfiles/ms/micons/blue-dot.png';
        //zoomControl: true,
        //zoomControlOptions: google.maps.ZoomControlStyle.LARGE,
        var mapOptions = {
                center: new google.maps.LatLng(lat, lng),
                zoom: 13,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                panControl: true,
                panControlOptions: {
                    position: google.maps.ControlPosition.TOP_RIGHT
                },
                zoomControl: true,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.LARGE,
                    position: google.maps.ControlPosition.TOP_left
                }
            },
            map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions),
            marker = new google.maps.Marker({
                position: latlng,
                map: map,
                icon: image
            });
        var input = document.getElementById('searchTextField');
		
        var autocomplete = new google.maps.places.Autocomplete(input, {
            types: ["geocode"]
        });
        autocomplete.bindTo('bounds', map);
        var infowindow = new google.maps.InfoWindow();
        google.maps.event.addListener(autocomplete, 'place_changed', function (event) {
            infowindow.close();
            var place = autocomplete.getPlace();
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }
            moveMarker(place.name, place.geometry.location);
            $('.MapLat').val(place.geometry.location.lat());
            $('.MapLon').val(place.geometry.location.lng());
        });
        google.maps.event.addListener(map, 'click', function (event) {
            $('.MapLat').val(event.latLng.lat());
            $('.MapLon').val(event.latLng.lng());
            infowindow.close();
            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                "latLng":event.latLng
            }, function (results, status) {
                console.log(results, status);
                if (status == google.maps.GeocoderStatus.OK) {
                    console.log(results);
                    var lat = results[0].geometry.location.lat(),
                        lng = results[0].geometry.location.lng(),
                        placeName = results[0].address_components[0].long_name,
                        latlng = new google.maps.LatLng(lat, lng);
                    moveMarker(placeName, latlng);
                    $("#searchTextField").val(results[0].formatted_address);
                }
            });
        });

        function moveMarker(placeName, latlng) {
            marker.setIcon(image);
            marker.setPosition(latlng);
            infowindow.setContent(placeName);
            //infowindow.open(map, marker);
        } 
    });
</script>
