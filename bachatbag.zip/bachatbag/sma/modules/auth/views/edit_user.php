<script src="<?php echo $this->config->base_url(); ?>assets/js/validation.js"></script>

<script type="text/javascript">
$(function() {
	$(".user-role .btn").click(function() {
    // whenever a button is clicked, set the hidden helper
    $("#role").val($(this).val());
}); 
});
</script>
<script type="text/javascript">
$(function() {
	$('.selectsuppiler').hide();
			$('.selectcrm').hide();

	$('form').form();
	
	
	$('#supp').click(function(){
	$('.selectsuppiler').toggle();
	});
	
	$('.crm').click(function(){
			$('.selectcrm').toggle();
	});
	});
</script>
<!-- Errors -->
<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<h3 class="title"><?php echo $page_title ?></h3>
<p><?php echo $this->lang->line("update_user_info"); ?></p>
<?php $first_name = array(
              'name'        => 'first_name',
              'id'          => 'first_name',
			  'placeholder' => "First Name",
              'value'       => $user->first_name,
              'class'       => 'span4'
            );
			$last_name = array(
              'name'        => 'last_name',
              'id'          => 'last_name',
              'value'       => $user->last_name,
              'class'       => 'span4'
            );
			$company = array(
              'name'     => 'company',
              'id'          => 'company',
              'value'       => $user->company,
              'class'       => 'span4',
            );
			$phone = array(
              'name'        => 'phone',
              'id'          => 'phone',
              'value'       => $user->phone,
              'class'       => 'span4',
            );
			$email = array(
              'name'        => 'email',
              'id'          => 'email',
              'value'       => $user->email,
              'class'       => 'span4',
            );
			
	?>
<?php $attrib = array('class' => 'form-horizontal'); echo form_open("module=auth&view=edit_user&id=".$id, $attrib);?>
<div class="control-group">
  <label class="control-label" for="first_name"><?php echo $this->lang->line("first_name"); ?></label>
  <div class="controls"> <?php echo form_input($first_name);?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="last_name"><?php echo $this->lang->line("last_name"); ?></label>
  <div class="controls"> <?php echo form_input($last_name);?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="company"><?php echo $this->lang->line("company"); ?></label>
  <div class="controls"> <?php echo form_input($company);?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("phone"); ?></label>
  <div class="controls"> <?php echo form_input($phone);?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="email"><?php echo $this->lang->line("email_address"); ?></label>
  <div class="controls"> <?php echo form_input($email);?> </div>
</div>
<!--<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("user_role"); ?></label>
  <div class="controls"> 

<label class="radio">
        <input type="radio" name="role" id="optionsRadios1" value="1" <?php if($group->group_id == '1') { echo "checked=\"yes\""; } if(isset($_POST['submit']) && ($_POST['role'] == '1')) { echo "checked=\"yes\""; } ?>>
        <?php echo $this->lang->line("owner_role"); ?> </label>
      <label class="radio">
        <input type="radio" name="role" id="optionsRadios2" value="2" <?php if($group->group_id == '2') { echo "checked=\"yes\""; } if(isset($_POST['submit']) && ($_POST['role'] == '2')) { echo "checked=\"yes\""; } ?>>
        <?php echo $this->lang->line("admin_role"); ?> </label>
      <label class="radio">
        <input type="radio" name="role" id="optionsRadios3" value="3" <?php if($group->group_id == '3') { echo "checked=\"yes\""; } if(isset($_POST['submit']) && ($_POST['role'] == '3')) { echo "checked=\"yes\""; } ?>>
        <?php echo $this->lang->line("purchaser_role"); ?> </label>
        <label class="radio">
        <input type="radio" name="role" id="optionsRadios4" value="4" <?php if($group->group_id == '4') { echo "checked=\"yes\""; } if(isset($_POST['submit']) && ($_POST['role'] == '4')) { echo "checked=\"yes\""; } ?>>
        <?php echo $this->lang->line("salesman_role"); ?> </label>
      <label class="radio">
        <input type="radio" name="role" id="optionsRadios5" value="5" <?php if($group->group_id == '5') { echo "checked=\"yes\""; } if(isset($_POST['submit']) && ($_POST['role'] == '5')) { echo "checked=\"yes\""; } ?>>
        <?php echo $this->lang->line("view_role"); ?> </label>
  </div>
</div>     -->
<div class="control-group">
  <label class="control-label" for="phone"><?php echo $this->lang->line("user_role"); ?></label>
  <div class="controls">
      <div class="btn-group user-role" data-toggle="buttons-radio">
    <button type="button" value="1" class="btn <?php if($group->group_id == '1') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '1')) { echo "active"; } ?>"><?php echo $this->lang->line("owner"); ?></button>
    <button type="button" value="2" class="btn <?php if($group->group_id == '2') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '2')) { echo "active"; } ?>"><?php echo $this->lang->line("admin"); ?></button>
    <button type="button" value="10" class="btn <?php if($group->group_id == '3') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '3')) { echo "active"; } ?>"><?php echo $this->lang->line("superadmin"); ?></button>
    <button type="button" value="11" class="btn crm <?php if($group->group_id == '4') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '4')) { echo "active"; } ?>"><?php echo $this->lang->line("crm"); ?></button>
   <button type="button" value="12" class="btn  crm<?php if($group->group_id == '4') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '4')) { echo "active"; } ?>"><?php echo $this->lang->line("inventorymanager"); ?></button>

   <button type="button" value="5" class="btn <?php if($group->group_id == '5') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '5')) { echo "active"; } ?>"><?php echo $this->lang->line("user"); ?></button>
    <button type="button" value="6" id="supp" class="btn <?php if($group->group_id == '6') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '6')) { echo "active"; } ?>"><?php echo $this->lang->line("supplier"); ?></button>
    <button type="button" value="8" class="btn <?php if($group->group_id == '7') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '7')) { echo "active"; } ?>"><?php echo $this->lang->line("customer"); ?></button>
    <button type="button" value="9" class="btn <?php if($group->group_id == '7') { echo "active"; } if(isset($_POST['submit']) && ($_POST['role'] == '7')) { echo "active"; } ?>"><?php echo $this->lang->line("warehouse"); ?></button>

   </div>
    <input type="hidden" name="role" id="role" value="<?php echo $group->group_id; ?>">
 </div>
</div> 
<div class="control-group selectsuppiler">
  <label class="control-label" for="password"><?php echo $this->lang->line("catalog"); ?></label>
  <div class="controls"> <select name="catalog">
  <option value="">Select Catalog</option>

  <?php foreach($selectsuppiler as $r) { ?>
  <option value="<?php echo $r->name; ?>"><?php echo $r->name; ?></option>
  <?php } ?>
  </select> </div>
</div>  

<style>
.tableuser td{
		width:150px;
}
</style>
<div class="control-group selectcrm">
  <label class="control-label" for="password"><?php echo $this->lang->line("select"); ?></label>
  <div class="controls"> 
  <table class="tableuser">
  <tr>
<td><input type="checkbox" name="catalog" value="1" <?php echo ($menu_settings->catalog ==1 ? 'checked' : '');?> > Catalog</td>
<td><input type="checkbox" name="categories" value="1" <?php echo ($menu_settings->categories ==1 ? 'checked' : '');?> > Categories</td>
<td><input type="checkbox" name="suppliers" value="1" <?php echo ($menu_settings->suppliers ==1 ? 'checked' : '');?>> Suppliers</td>
<td><input type="checkbox" name="customer" value="1" <?php echo ($menu_settings->customer ==1 ? 'checked' : '');?>> Customers</td>
<td><input type="checkbox" name="products" value="1" <?php echo ($menu_settings->products ==1 ? 'checked' : '');?>> Products</td></tr>
<tr><td><input type="checkbox" name="warehouse" value="1" <?php echo ($menu_settings->warehouse ==1 ? 'checked' : '');?>> Warehouse</td>
<td><input type="checkbox" name="transfers" value="1" <?php echo ($menu_settings->transfers ==1 ? 'checked' : '');?>> Transfers</td>
<td><input type="checkbox" name="purchases" value="1" <?php echo ($menu_settings->purchases ==1 ? 'checked' : '');?>> Purchases</td>
<td><input type="checkbox" name="sales" value="1" <?php echo ($menu_settings->sales ==1 ? 'checked' : '');?>> Sales</td>
<td><input type="checkbox" name="deliveries" value="1" <?php echo ($menu_settings->deliveries ==1 ? 'checked' : '');?>> Deliveries</td></tr>
<tr><td><input type="checkbox" name="quotation" value="1" <?php echo ($menu_settings->quotation ==1 ? 'checked' : '');?>> Quotation</td>
<td><input type="checkbox" name="people" value="1" <?php echo ($menu_settings->people ==1 ? 'checked' : '');?>> People</td>
<td><input type="checkbox" name="discount" value="1" <?php echo ($menu_settings->discount ==1 ? 'checked' : '');?>> Discount</td>
<td><input type="checkbox" name="settings" value="1" <?php echo ($menu_settings->settings ==1 ? 'checked' : '');?>> Settings</td>
<td><input type="checkbox" name="reports" value="1" <?php echo ($menu_settings->reports ==1 ? 'checked' : '');?>> Reports</td></tr>
<tr><td><input type="checkbox" name="backup_database" value="1" <?php echo ($menu_settings->backup_database ==1 ? 'checked' : '');?>> Backup Database</td>
</tr>
</table>
  </div>
</div>
    
<div class="control-group">
  <label class="control-label" for="password"><?php echo $this->lang->line("pw"); ?></label>
  <div class="controls"> <?php echo form_input($password , $user->password, 'class="password span4" id="password"');?> </div>
</div>
<div class="control-group">
  <label class="control-label" for="confirm_pw"><?php echo $this->lang->line("confirm_pw"); ?></label>
  <div class="controls"> <?php echo form_input($password_confirm , '', 'class="password span4" id="confirm_pw"');?> </div>
</div>
<div class="control-group">
  <div class="controls"> <?php echo form_submit('submit', $this->lang->line("update_user"), 'class="btn btn-primary"');?> </div>
</div>
<?php echo form_close();?>

