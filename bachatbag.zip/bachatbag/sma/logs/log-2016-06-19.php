<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-19 11:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 11:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 11:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 11:13:37 --> Could not find the language line "comment"
ERROR - 2016-06-19 11:13:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 11:13:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 11:15:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 11:15:12 --> Could not find the language line "comment"
ERROR - 2016-06-19 11:15:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 11:15:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:33:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:33:51 --> Could not find the language line "comment"
ERROR - 2016-06-19 15:33:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:33:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:33:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:33:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:33:55 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-19 15:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 465
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 466
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 467
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: code C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 182
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 183
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: companyname C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 184
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: category_id C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 185
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: subcategory_id C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 186
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: unit C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 187
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cost C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 188
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: price C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 189
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: alert_quantity C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 190
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: tax_rate C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 191
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: track_quantity C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 192
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf1 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 193
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf2 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 194
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf3 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 195
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf4 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 196
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf5 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 197
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cf6 C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 198
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: details C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 199
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: display_in_client_side C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 200
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: related_product C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 201
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: daily_deals C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 202
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: feature_product C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 203
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: new_products C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 204
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: best_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 205
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: cross_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 206
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: up_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 207
ERROR - 2016-06-19 15:35:12 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 208
ERROR - 2016-06-19 15:35:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:35:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:35:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-19 15:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:14 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 465
ERROR - 2016-06-19 15:36:14 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 466
ERROR - 2016-06-19 15:36:14 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 467
ERROR - 2016-06-19 15:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:36:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:39:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:39:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:39:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-19 15:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:48:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:48:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:48:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:48:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:48:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-19 15:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-19 15:50:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:50:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-19 15:50:39 --> Could not find the language line "pr_category_tip"
