<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-16 10:53:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 10:53:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-16 10:53:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 10:53:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 10:54:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 10:54:02 --> 404 Page Not Found --> 
ERROR - 2016-07-16 10:58:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 10:58:25 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:02:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:02:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:02:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:02:49 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:04:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:04:29 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:19:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:19:59 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:21:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:21:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:28:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:28:22 --> 404 Page Not Found --> 
ERROR - 2016-07-16 11:35:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 11:35:17 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:02:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:02:27 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:03:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:03:59 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:05:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:05:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:09:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:09:10 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:09:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:09:14 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:21:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:21:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:21:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:21:34 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:21:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:21:54 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:21:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:21:56 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:24:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:24:08 --> 404 Page Not Found --> 
ERROR - 2016-07-16 13:24:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 13:24:24 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:26:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:26:40 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:26:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:26:42 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:38:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:38:55 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:38:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:38:59 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:39:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:39:08 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:40:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:40:22 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:40:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:40:22 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:40:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:40:27 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:43:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:43:57 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:44:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:44:15 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:44:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:44:19 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:44:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:44:30 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:46:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:46:07 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:47:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:47:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:51:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:51:30 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:55:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:55:46 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:58:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:58:51 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:59:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:59:27 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:59:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:59:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 15:59:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 15:59:52 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:02:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:02:37 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:02:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:02:37 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:03:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:03:10 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:03:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:03:21 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:03:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:03:32 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:03:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:03:32 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:04:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:04:53 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:05:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:05:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:05:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:05:15 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:05:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:05:20 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:06:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:06:20 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:09 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:09 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:24 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:24 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:30 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:40 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:40 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:55 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:07:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:07:55 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:08:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:08:01 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:08:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:08:08 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:08:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:08:53 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:08 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:09 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:33 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:09:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:09:38 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:10:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:10:26 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:12:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:12:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:12:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:12:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:13:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:13:48 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:14:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:14:33 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:14:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:14:33 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:16:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:16:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:16:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:16:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:19 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:23 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:47 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:49 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:20:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:20:52 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:26:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:26:16 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:27:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:27:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:27:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:27:07 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:27:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:27:54 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:27:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:27:56 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:28:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:28:00 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:28:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:28:03 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:28:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:28:46 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:28:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:28:59 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:52:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:52:50 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:54:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:54:14 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:54:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:54:19 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:34 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:36 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:37 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:41 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:52 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:56 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:55:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:55:56 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:56:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:56:01 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:56:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:56:09 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:32 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:37 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:41 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:45 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:50 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:57:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:57:55 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:58:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:58:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:59:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:59:13 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:59:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:59:54 --> 404 Page Not Found --> 
ERROR - 2016-07-16 16:59:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 16:59:57 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:02:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:02:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:02:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:02:40 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:04:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:04:24 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:04:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:04:28 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:04:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:04:46 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:05:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:05:51 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:05:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:05:54 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:07:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:07:08 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:07:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:07:11 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:07:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:07:13 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:08:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:08:36 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:12:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:12:24 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:12:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:12:26 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:17:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:17:41 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:17:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:17:45 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:23:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:23:49 --> 404 Page Not Found --> 
ERROR - 2016-07-16 17:23:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 17:23:54 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:15:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:15:22 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:15:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:15:23 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:15:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:15:42 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:15:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:15:46 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:16:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:16:05 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:16:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:16:07 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:16:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:16:44 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:22:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:22:04 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:22:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:22:40 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:22:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:22:44 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:23:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:23:01 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:23:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:23:04 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:23:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:23:29 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:23:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:23:31 --> 404 Page Not Found --> 
ERROR - 2016-07-16 18:33:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-16 18:33:47 --> 404 Page Not Found --> 
