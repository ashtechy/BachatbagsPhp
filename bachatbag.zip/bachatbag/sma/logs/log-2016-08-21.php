<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-21 19:24:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:26 --> Severity: Notice  --> Undefined index: HTTP_REFERER /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/controllers/home.php 153
ERROR - 2016-08-21 19:24:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:27 --> Could not find the language line "comment"
ERROR - 2016-08-21 19:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-21 19:24:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:40 --> Could not find the language line "comment"
ERROR - 2016-08-21 19:24:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-21 19:24:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "comment"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "edit_ann"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "catalog"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "add_catalog"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "list_catalog"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "channelpartner"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "list_partner"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "new_partner"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "add_partner_by_csv"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "print_barcodes"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "print_labels"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "loyaltypoints"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "cartmanagement"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "cartmanagement"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "ratings"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "ratings"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "daily_sales"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "monthly_sales_purchases"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "sp_tax"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "pp_tax"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "by_price"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "by_cost"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "best_sellers"
ERROR - 2016-08-21 19:24:44 --> Could not find the language line "total_sold"
ERROR - 2016-08-21 19:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-21 19:25:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:25:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:25:02 --> Could not find the language line "comment"
ERROR - 2016-08-21 19:25:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-21 19:25:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:25:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-21 19:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-21 19:25:27 --> Could not find the language line "August"
