<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-01 15:24:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:24:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:24:23 --> Could not find the language line "comment"
ERROR - 2016-06-01 15:24:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\home\views\content.php 188
ERROR - 2016-06-01 15:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:24:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-01 15:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:24:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:28:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:28:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:28:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:28:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-01 15:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:29:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:29:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:29:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-01 15:29:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:29:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:29:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:30:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:30:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:30:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-01 15:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-01 15:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
