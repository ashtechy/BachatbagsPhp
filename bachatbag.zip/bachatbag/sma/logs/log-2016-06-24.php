<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-24 09:51:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 09:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 09:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 15:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 15:34:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 15:34:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 15:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:06:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:06:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:06:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:06:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-24 17:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:06:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:06:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:06:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-24 17:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:07:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:07:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-24 17:07:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:07:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-24 17:07:17 --> Could not find the language line "pr_category_tip"
