<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-28 10:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:08:49 --> Could not find the language line "comment"
ERROR - 2016-06-28 10:08:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:08:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:09:04 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:09:04 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:09:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:09:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:09:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:15:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:15:10 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:15:10 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:22:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:22:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:22:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:22:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:22:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:23:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:23:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:27:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:27:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:27:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:27:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:27:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:28:18 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octbell\sma\modules\categories\controllers\categories.php 88
ERROR - 2016-06-28 10:28:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:28:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:28:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:28:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:28:52 --> The upload path does not appear to be valid.
ERROR - 2016-06-28 10:28:52 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:30:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:30:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:30:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:30:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:30:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:30:59 --> The upload path does not appear to be valid.
ERROR - 2016-06-28 10:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:30:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:30:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:31:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:31:00 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:31:00 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:32:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:32:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:32:55 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:32:55 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:34:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:34:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:34:08 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:39:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:39:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:39:49 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:39:49 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:39:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:39:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:31 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:40:31 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:40:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:40:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:40:58 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:40:58 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:03 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:41:03 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:08 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:41:08 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:41:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:42:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:42:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:42:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:45:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:45:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:45:43 --> Severity: Notice  --> Undefined variable: catalogs C:\xampp\htdocs\octbell\sma\modules\products\views\add.php 188
ERROR - 2016-06-28 10:45:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\add.php 188
ERROR - 2016-06-28 10:45:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:45:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:46:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:47:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:47:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:47:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:47:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:47:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:49:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:49:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:49:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:49:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:49:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:49:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:51:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:51:56 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:51:56 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:51:56 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:52:23 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-06-28 10:52:23 --> You did not select a file to upload.
ERROR - 2016-06-28 10:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:52:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:52:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:52:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:52:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:52:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:54:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:54:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:54:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:54:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:54:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:54:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:55:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:55:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:55:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:55:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:55:40 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:55:40 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:56:44 --> You did not select a file to upload.
ERROR - 2016-06-28 10:56:44 --> You did not select a file to upload.
ERROR - 2016-06-28 10:56:44 --> You did not select a file to upload.
ERROR - 2016-06-28 10:56:44 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 717
ERROR - 2016-06-28 10:56:44 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 718
ERROR - 2016-06-28 10:56:44 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 719
ERROR - 2016-06-28 10:56:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 728
ERROR - 2016-06-28 10:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:56:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:56:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:08 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:08 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:25 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:25 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:25 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:25 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 717
ERROR - 2016-06-28 10:57:25 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 718
ERROR - 2016-06-28 10:57:25 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 719
ERROR - 2016-06-28 10:57:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 728
ERROR - 2016-06-28 10:57:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:44 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:44 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 728
ERROR - 2016-06-28 10:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 10:57:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:55 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:55 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:55 --> You did not select a file to upload.
ERROR - 2016-06-28 10:57:55 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 717
ERROR - 2016-06-28 10:57:55 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 718
ERROR - 2016-06-28 10:57:55 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 719
ERROR - 2016-06-28 10:57:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 728
ERROR - 2016-06-28 10:57:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:57:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:58:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:58:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:58:28 --> Could not find the language line "catallog"
ERROR - 2016-06-28 10:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:58:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:58:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:58:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:58:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 10:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 10:58:32 --> 404 Page Not Found --> 
ERROR - 2016-06-28 10:58:32 --> 404 Page Not Found --> 
ERROR - 2016-06-28 11:07:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:08 --> Could not find the language line "comment"
ERROR - 2016-06-28 11:07:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:07:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:07:33 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:33 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:07:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:07:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 439
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 448
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 449
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 450
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 451
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Undefined index: userfile C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 452
ERROR - 2016-06-28 11:08:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:08:08 --> You did not select a file to upload.
ERROR - 2016-06-28 11:08:09 --> You did not select a file to upload.
ERROR - 2016-06-28 11:08:09 --> The file was only partially uploaded.
ERROR - 2016-06-28 11:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:09 --> You did not select a file to upload.
ERROR - 2016-06-28 11:08:09 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-06-28 11:08:09 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:08:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:08:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:08:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:20:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:20:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:20:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:20:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:20:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:20:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:20:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:20:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:20:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:21:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:21:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:21:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:21:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:21:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:21:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:21:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:21:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:22:48 --> The path to the image is not correct.
ERROR - 2016-06-28 11:22:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-28 11:22:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:22:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:22:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:51 --> 404 Page Not Found --> 
ERROR - 2016-06-28 11:22:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:51 --> 404 Page Not Found --> 
ERROR - 2016-06-28 11:22:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:22:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:22:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:22:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:23:13 --> The path to the image is not correct.
ERROR - 2016-06-28 11:23:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-28 11:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:23:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:23:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:13 --> 404 Page Not Found --> 
ERROR - 2016-06-28 11:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:13 --> 404 Page Not Found --> 
ERROR - 2016-06-28 11:23:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:23:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:23:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:23:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:23:41 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:23:41 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:24:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:24:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:24:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:24:26 --> You did not select a file to upload.
ERROR - 2016-06-28 11:24:26 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-06-28 11:24:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:24:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:24:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:24:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:43:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:43:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:43:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:43:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:43:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:43:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 11:43:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:43:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:43:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:43:59 --> You did not select a file to upload.
ERROR - 2016-06-28 11:43:59 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-06-28 11:43:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 11:43:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:43:59 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 11:43:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 11:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 12:12:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:12:38 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:12:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:12:38 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:14:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:14:05 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:14:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:14:06 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:14:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:14:43 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:14:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:14:44 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:15:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:15:02 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:15:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:15:02 --> 404 Page Not Found --> 
ERROR - 2016-06-28 12:53:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 12:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 12:53:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 12:53:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 12:53:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 12:53:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 12:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-06-28 12:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-06-28 13:00:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:00:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:00:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:00:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:01:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:01:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:01:11 --> The path to the image is not correct.
ERROR - 2016-06-28 13:01:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-28 13:01:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:01:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:01:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:01:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:01:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:01:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:01:12 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:01:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:01:12 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:05:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:05:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:05:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:05:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:11:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:11:44 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:11:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:11:45 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:13:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:13:12 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:13:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:13:12 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:14:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:14:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:14:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:14:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:14:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:14:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:14:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:14:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:14:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:14:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:14:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-06-28 13:14:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-06-28 13:15:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:15:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-28 13:15:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:38 --> You did not select a file to upload.
ERROR - 2016-06-28 13:15:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-28 13:15:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-28 13:15:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:45 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:15:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:15:45 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:16:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:16:13 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:16:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:16:13 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:16:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:16:33 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:16:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:16:34 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:18:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:18:23 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:18:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:18:23 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:23:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:23:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:23:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:23:29 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:24:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:24:57 --> 404 Page Not Found --> 
ERROR - 2016-06-28 13:24:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-28 13:24:57 --> 404 Page Not Found --> 
