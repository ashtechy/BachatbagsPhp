<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-21 17:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:15 --> Could not find the language line "comment"
ERROR - 2016-06-21 17:34:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:34:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:35:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:35:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:35:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:35:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:35:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:35:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-21 17:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 463
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 464
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 465
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 466
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 467
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 463
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 464
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 465
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 466
ERROR - 2016-06-21 17:37:26 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 467
ERROR - 2016-06-21 17:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:37:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:37:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:37:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-21 17:37:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:37:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-21 17:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
