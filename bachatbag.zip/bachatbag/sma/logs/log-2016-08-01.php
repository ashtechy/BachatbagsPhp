<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-01 10:18:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:18:15 --> 404 Page Not Found --> 
ERROR - 2016-08-01 10:18:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:18:53 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:18:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:18:56 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:18:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:18:57 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:18:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:18:58 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:19:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:19:35 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:21:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:21:36 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:21:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:21:39 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:21:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:21:53 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:23:13 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:15 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:16 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:20 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:20 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:21 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:21 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:21 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:21 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:21 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:22 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:22 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:33:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:33:22 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:38:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:38:08 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:38:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:38:09 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:40:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:40:26 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:41:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:41:13 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:41:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:41:14 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:41:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:41:16 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:45:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:45:07 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 10:45:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 10:45:08 --> Severity: Warning  --> Declaration of MY_Lang::line($line, $params = NULL) should be compatible with CI_Lang::line($line = '') C:\xampp\htdocs\octobel_old\admin\sma\core\MY_Lang.php 43
ERROR - 2016-08-01 13:21:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:21:51 --> 404 Page Not Found --> 
ERROR - 2016-08-01 13:21:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:21:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:22:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:22:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:22:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:22:42 --> Could not find the language line "comment"
ERROR - 2016-08-01 13:22:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:22:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:22:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-08-01 13:49:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:49:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:49:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:49:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:49:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:49:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 13:49:53 --> Could not find the language line "catallog"
ERROR - 2016-08-01 13:49:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 13:49:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:49:55 --> 404 Page Not Found --> 
ERROR - 2016-08-01 13:49:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 13:49:55 --> 404 Page Not Found --> 
ERROR - 2016-08-01 14:55:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 14:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 14:55:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 14:55:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 14:55:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 14:55:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 14:56:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 14:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 14:57:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 14:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 14:57:19 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 477
ERROR - 2016-08-01 14:57:19 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 478
ERROR - 2016-08-01 14:57:19 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 479
ERROR - 2016-08-01 14:57:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 14:57:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 14:57:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 14:57:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 14:57:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 14:57:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 15:01:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:01:58 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:06:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:06:37 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:06:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:06:42 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:09:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:09:25 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:10:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:10:32 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:10:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:10:56 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:11:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:11:03 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:19:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:19:48 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:36:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:36:30 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:36:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:36:49 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:36:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:36:54 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:39:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:39:04 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:39:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:39:47 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:40:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:40:00 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:40:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:40:29 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:40:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:40:45 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:41:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:41:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:41:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:41:28 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:41:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:41:28 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:42:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:42:38 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:42:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:42:38 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:44:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:44:03 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:44:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:44:19 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:44:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:44:22 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:44:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:44:41 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:46:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:46:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:46:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:46:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:46:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:46:13 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:46:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:46:18 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:46:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:46:22 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:47:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:47:02 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:48:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:48:06 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:50:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:50:02 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:50:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:50:36 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:51:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:51:23 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:54:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:54:45 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:54:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:54:45 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:54:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:54:59 --> 404 Page Not Found --> 
ERROR - 2016-08-01 15:56:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 15:56:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 15:56:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 15:56:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 15:56:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 15:57:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 15:58:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 15:58:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 15:58:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 15:58:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 15:58:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 15:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 16:06:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:06:54 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:07:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:07:48 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:08:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:08:52 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:09:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:09:13 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:09:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:09:26 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:10:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:10:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:10:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:10:18 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:10:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:10:25 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:16:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:16:12 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:20:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:20:32 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:21:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:21:52 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:22:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:22:33 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:22:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:22:39 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:23:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:23:06 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:24:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:24:05 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:26:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:26:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:26:29 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:26:29 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:26:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:26:29 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:27:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:27:53 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:29:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:29:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:29:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:29:57 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:30:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:30:15 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:30:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:30:21 --> 404 Page Not Found --> 
ERROR - 2016-08-01 16:30:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 16:30:34 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:14:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:14:54 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:15:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:15:14 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:15:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:15:16 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:28:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:28:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:28:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:28:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:28:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:28:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:28:51 --> Could not find the language line "comment"
ERROR - 2016-08-01 17:28:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:28:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:28:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-08-01 17:29:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:29:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:29:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:29:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:29:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:29:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:29:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:29:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:29:58 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 17:29:58 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 17:29:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-08-01 17:29:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 256
ERROR - 2016-08-01 17:29:59 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 322
ERROR - 2016-08-01 17:31:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:31:14 --> You did not select a file to upload.
ERROR - 2016-08-01 17:31:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-08-01 17:31:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:31:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:31:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:31:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:32:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:32:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:32:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:32:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 17:32:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 17:33:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:35:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:35:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:35:11 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-08-01 17:35:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:35:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:35:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 17:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 17:35:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:35:21 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:36:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:36:08 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:36:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:36:08 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:46:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:46:16 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:47:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:47:02 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:47:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:47:56 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:48:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:48:26 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:50:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:50:41 --> 404 Page Not Found --> 
ERROR - 2016-08-01 17:51:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 17:51:22 --> 404 Page Not Found --> 
ERROR - 2016-08-01 18:21:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 18:21:58 --> 404 Page Not Found --> 
ERROR - 2016-08-01 18:23:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 18:23:04 --> 404 Page Not Found --> 
ERROR - 2016-08-01 18:24:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 18:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 18:25:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 18:25:09 --> 404 Page Not Found --> 
ERROR - 2016-08-01 18:25:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 18:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 18:25:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 18:25:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-01 18:25:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 18:25:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-01 19:35:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 19:35:42 --> 404 Page Not Found --> 
ERROR - 2016-08-01 19:36:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 19:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-01 19:36:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-01 19:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
