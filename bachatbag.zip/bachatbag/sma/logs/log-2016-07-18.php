<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-18 08:59:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 08:59:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:00:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:00:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:00:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:00:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:00:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:00:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:00:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:00:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:06:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:06:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:09:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:09:15 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:09:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:09:31 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:09:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:09:33 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:09:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:09:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:09:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:09:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 09:16:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 09:16:33 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:12:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:12:02 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:12:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:12:12 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:12:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:12:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:18:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:18:56 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:19:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:19:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:34:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:34:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:35:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:35:12 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:35:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:35:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:35:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:35:23 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:35:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:35:27 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:35:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:35:43 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:39:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:39:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 10:51:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 10:51:33 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:11:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:11:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:13:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:13:34 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:13:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:13:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:14:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:14:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:15:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:15:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:15:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:15:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:15:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:15:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:16:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:16:24 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:16:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:16:51 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:19:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:19:22 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:20:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:20:00 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:20:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:20:15 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:21:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:21:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:22:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:22:49 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:22:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:22:55 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:23:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:23:00 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:23:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:23:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:29:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:29:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:32:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:32:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 11:55:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 11:55:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 11:55:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 11:56:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 11:56:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 11:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 11:56:01 --> Could not find the language line "comment"
ERROR - 2016-07-18 11:56:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 11:56:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 11:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-18 12:01:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:01:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:02:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:02:16 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:03:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:03:48 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:04:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:04:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:04:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:04:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:05:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:05:22 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:05:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:05:34 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:06:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:06:19 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:07:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:07:07 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:07:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:07:11 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:07:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:07:50 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:07:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:07:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:07:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:07:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:08:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:08:02 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:08:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:08:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:14:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:14:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:14:24 --> Could not find the language line "comment"
ERROR - 2016-07-18 12:14:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:14:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-18 12:16:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:16:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:16:43 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:16:43 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:16:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:16:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:16:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:16:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:16:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:16:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:00 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:00 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:00 --> Could not find the language line "no_suggestions"
ERROR - 2016-07-18 12:17:00 --> Could not find the language line "no_suggestions"
ERROR - 2016-07-18 12:17:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:07 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:07 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:07 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:07 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:17:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 12:17:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 12:17:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 12:17:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 12:34:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:34:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:34:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:34:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:34:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:34:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:02 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:15 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:27 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 12:47:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 12:47:44 --> 404 Page Not Found --> 
ERROR - 2016-07-18 13:01:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 13:01:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 13:02:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 13:02:19 --> 404 Page Not Found --> 
ERROR - 2016-07-18 14:44:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 14:44:12 --> 404 Page Not Found --> 
ERROR - 2016-07-18 14:44:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 14:44:19 --> 404 Page Not Found --> 
ERROR - 2016-07-18 14:44:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 14:44:22 --> 404 Page Not Found --> 
ERROR - 2016-07-18 14:44:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 14:44:24 --> 404 Page Not Found --> 
ERROR - 2016-07-18 14:44:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 14:44:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:14:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:14:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:31 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:14:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:39 --> Could not find the language line "comment"
ERROR - 2016-07-18 15:14:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:39 --> Could not find the language line "comment"
ERROR - 2016-07-18 15:14:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-18 15:14:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-18 15:14:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:14:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:14:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:14:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 15:14:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 15:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-18 15:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-07-18 15:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:19:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 719
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 720
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 721
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 719
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 720
ERROR - 2016-07-18 15:19:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 721
ERROR - 2016-07-18 15:19:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-18 15:19:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:19:10 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:19:10 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:19:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:21:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:21:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:22:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:22:11 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:22:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:22:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:23:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:23:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:23:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:23:48 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:24:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:24:30 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:26:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:26:33 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:26:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:26:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:26:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:26:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:26:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:26:43 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:26:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:26:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:28:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:28:08 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:28:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:28:54 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:33:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:33:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:33:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:33:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:35:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:35:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:35:24 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:35:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:35:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:36:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:36:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:37:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:37:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:38:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:38:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:39:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:39:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 15:39:31 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:39:31 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 15:39:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 15:39:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 15:39:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-07-18 15:39:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-07-18 15:43:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:43:15 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:44:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:44:34 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:44:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:44:53 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:46:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:46:11 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:46:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:46:22 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:46:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:46:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:47:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:47:05 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:47:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:47:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:47:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:47:58 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:50:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:50:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:51:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:51:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:52:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:52:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:52:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:52:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:52:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:52:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:52:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:52:46 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:55:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:55:00 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:55:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:55:50 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:56:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:56:19 --> 404 Page Not Found --> 
ERROR - 2016-07-18 15:57:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 15:57:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:00:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:00:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:00:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:00:54 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:01:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:01:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:01:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:01:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:01:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:01:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:01:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:01:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:03:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:03:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:03:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:03:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:03:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:03:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:03:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:03:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:13:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:13:14 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:13:14 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:13:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 16:13:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 16:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 256
ERROR - 2016-07-18 16:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 322
ERROR - 2016-07-18 16:13:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:13:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:13:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:13:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:13:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:13:28 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\view_image.php 5
ERROR - 2016-07-18 16:13:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:13:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:13:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:13:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:14:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:14:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:14:13 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:14:13 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 16:14:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:14:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:14:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:14:16 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\view_image.php 5
ERROR - 2016-07-18 16:15:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:15:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:16:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:16:04 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:16:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:16:50 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:20:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:20:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:20:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:20:23 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:20:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:20:26 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:20:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:20:34 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:20:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:20:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:22:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:22:18 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:22:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:22:23 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:22:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:22:26 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:22:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:22:43 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:23:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:23:08 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:23:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:23:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:28:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:28:54 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:29:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:29:00 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:29:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:29:00 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:29:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:29:08 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:29:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:29:12 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:40:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:40:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:40:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:40:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:41:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:41:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:41:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:41:52 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:44:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:44:18 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:44:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:44:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:44:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 16:45:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:45:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:46:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:46:39 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:46:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:46:43 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:20 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:20 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:31 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:44 --> 404 Page Not Found --> 
ERROR - 2016-07-18 16:47:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 16:47:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:18:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:18:34 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:18:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:18:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:18:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:18:37 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:21:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:21:20 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:26:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:26:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:27:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:27:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:29:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:29:05 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:30:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:30:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:31:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:31:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:31:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:31:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:31:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:31:50 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:31:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:31:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:32:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:32:40 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:33:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:33:52 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:33:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:33:55 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:34:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:34:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:19 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 17:34:19 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-18 17:34:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:34:22 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:22 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:34:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:34:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:34:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-18 17:34:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-18 17:35:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:35:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:37:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:37:51 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:38:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:38:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:39:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:39:46 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:40:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:40:10 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:40:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:40:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:41:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:41:23 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:42:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:42:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:42:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:42:19 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:43:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:43:52 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:45:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:45:55 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:46:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:46:20 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:47:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:47:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:48:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:48:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:49:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:49:08 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:49:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:49:58 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:51:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:51:13 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:54:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:54:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:55:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:55:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:56:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:56:39 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:57:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:57:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:58:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:58:24 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:59:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:59:56 --> 404 Page Not Found --> 
ERROR - 2016-07-18 17:59:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 17:59:58 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:00:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:00:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:00:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:00:48 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:01:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:01:56 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:02:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:02:05 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:02:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:02:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:03:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:03:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:04:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:04:22 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:04:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:04:55 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:05:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:05:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:06:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:06:48 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:07:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:07:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:07:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:07:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:07:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:07:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:09:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:09:26 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:09:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:09:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:09:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:09:52 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:12:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:12:49 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:13:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:13:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:14:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:14:10 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:24:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:24:39 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:27:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:27:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:28:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:28:53 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:29:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:29:07 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:29:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:29:42 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:30:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:30:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:30:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:30:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:30:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:30:53 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:31:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:31:18 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:31:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:31:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:31:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:31:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:32:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:32:16 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:33:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:33:11 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:34:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:34:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:34:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:34:44 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:36:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:36:02 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:36:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:36:10 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:37:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:37:43 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:38:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:38:38 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:39:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:39:11 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:39:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:39:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:39:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:39:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:40:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:40:50 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:41:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:41:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:41:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:41:45 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:42:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:42:04 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:42:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:42:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:43:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:43:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:43:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:43:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:44:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:44:06 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:44:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:44:20 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:50:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:50:36 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:52:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:52:04 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:52:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:52:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:52:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:52:32 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:54:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:54:12 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:56:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:56:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:57:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:57:03 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:58:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:58:59 --> 404 Page Not Found --> 
ERROR - 2016-07-18 18:59:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 18:59:01 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:00:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:00:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:00:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:00:33 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:01:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:01:41 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:01:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:01:56 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:02:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:02:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:02:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:02:54 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:02:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:02:57 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:09 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:21 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:26 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:28 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:35 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:03:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:03:58 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:04:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:04:29 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:05:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:05:25 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:09:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:09:17 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:09:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:09:27 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:09:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:09:47 --> 404 Page Not Found --> 
ERROR - 2016-07-18 19:10:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-18 19:10:02 --> 404 Page Not Found --> 
