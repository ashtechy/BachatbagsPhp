<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-03 11:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:48:28 --> Could not find the language line "comment"
ERROR - 2016-06-03 11:48:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:48:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\home\views\content.php 188
ERROR - 2016-06-03 11:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:48:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:48:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:56:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:56:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:56:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 496
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 497
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 498
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 499
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 496
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 497
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 498
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 499
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 496
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 497
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 498
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 499
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\models\sales_model.php 534
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\models\sales_model.php 534
ERROR - 2016-06-03 11:56:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\octbell\sma\modules\sales\models\sales_model.php 534
ERROR - 2016-06-03 11:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 11:56:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:56:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 11:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 12:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 12:59:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 12:59:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 12:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-03 13:13:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 13:13:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-03 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
