<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-14 16:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:31 --> Could not find the language line "comment"
ERROR - 2016-06-14 16:07:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:39 --> Could not find the language line "comment"
ERROR - 2016-06-14 16:07:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:07:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:07:51 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:13:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:13:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:13:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:13:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:19:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:19:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:19:50 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "related_product"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "daily_deals"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "feature_product"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "new_products"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "best_seller"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "cross_seller"
ERROR - 2016-06-14 16:23:17 --> Could not find the language line "up_seller"
ERROR - 2016-06-14 16:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "related_product"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "daily_deals"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "feature_product"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "new_products"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "best_seller"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "cross_seller"
ERROR - 2016-06-14 16:27:54 --> Could not find the language line "up_seller"
ERROR - 2016-06-14 16:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:28:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:28:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:28:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:28:57 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:30:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:30:17 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:30:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:30:17 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:30:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:30:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:30:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:30:57 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:31:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:31:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:31:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:31:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:31:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:35:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:35:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:35:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:35:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:35:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:36:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:36:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:36:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:36:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:37:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:37:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:39:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:39:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:41:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:41:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:41:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:41:20 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:49:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:49:39 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:52:12 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: related_product C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 203
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: daily_deals C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 204
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: feature_product C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 205
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: new_products C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 206
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: best_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 207
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: cross_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 208
ERROR - 2016-06-14 16:52:45 --> Severity: Notice  --> Undefined index: up_seller C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 209
ERROR - 2016-06-14 16:52:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:52:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:52:45 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:56:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:23 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:56:23 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:56:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:56:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:56:28 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:56:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:56:32 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:56:32 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:57:13 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 16:57:13 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 16:57:13 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 16:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:58:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:58:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:58:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:58:34 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:58:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:58:35 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 16:58:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 16:58:35 --> Could not find the language line "specification"
ERROR - 2016-06-14 16:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 16:59:18 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 16:59:18 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 16:59:18 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:00:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:00:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:00:29 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:00:29 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:00 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:04:00 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:04:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:04:05 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 443
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 444
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 445
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 446
ERROR - 2016-06-14 17:04:40 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 447
ERROR - 2016-06-14 17:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:04:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:09:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:09:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:10:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:10:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:10:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:10:06 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:11:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:11:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:14:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:14:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:14:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:14:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:14:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:14:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:14:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:14:41 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:14:41 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:14:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:15:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:15:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:16:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:16:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:17:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:17:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:17:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:17:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:17:53 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:18:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:18:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:18:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:18:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:19:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:19:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:19:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:19:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:19:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:19:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:20:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:20:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:20:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:20:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:20:26 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:20:26 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:21:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:21:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:22:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:22:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:26:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:26:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:26:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:27:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:27:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:34:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:34:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:34:40 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:34:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:34:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:34:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:34:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:34:42 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:35:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 449
ERROR - 2016-06-14 17:35:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 450
ERROR - 2016-06-14 17:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:36:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:36:42 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:36:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:36:46 --> Could not find the language line "specification"
ERROR - 2016-06-14 17:36:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-14 17:36:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:54 --> Could not find the language line "list_service_request"
ERROR - 2016-06-14 17:36:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-14 17:36:54 --> Could not find the language line "specification"
