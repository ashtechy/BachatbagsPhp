<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-22 10:52:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 10:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 10:53:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 10:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 10:53:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 10:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 10:53:01 --> Could not find the language line "comment"
ERROR - 2016-08-22 10:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-22 10:53:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 10:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 10:53:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 10:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:52:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:52:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:52:57 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 140
ERROR - 2016-08-22 14:52:57 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 141
ERROR - 2016-08-22 14:52:57 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 141
ERROR - 2016-08-22 14:52:57 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 142
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 140
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 141
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 141
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/libraries/Ion_auth.php 142
ERROR - 2016-08-22 14:53:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:53:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:53:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:53:24 --> Could not find the language line "comment"
ERROR - 2016-08-22 14:53:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-22 14:53:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:53:43 --> Could not find the language line "color"
ERROR - 2016-08-22 14:55:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 14:55:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 14:55:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 14:55:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 15:50:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 15:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 15:50:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 15:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 15:50:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 15:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 15:50:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 15:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 15:50:45 --> Could not find the language line "comment"
ERROR - 2016-08-22 15:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-22 15:50:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-22 15:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-22 15:50:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 15:50:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 105
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 115
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 116
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 117
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 118
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 119
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 120
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 121
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 122
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 123
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 124
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 125
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 126
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 127
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 128
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 129
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 130
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 131
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 132
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 133
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 134
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 135
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 137
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:37 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:12:37 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:12:38 --> You did not select a file to upload.
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:12:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:12:38 --> Unable to connect to the database
ERROR - 2016-08-22 17:12:38 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:46 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:46 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:46 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 105
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 115
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 116
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 117
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 118
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 119
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 120
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 121
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 122
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 123
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 124
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 125
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 126
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 127
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 128
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 129
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 130
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 131
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 132
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 133
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 134
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 135
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 137
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 105
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 115
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 116
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 117
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 118
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 119
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 120
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 121
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 122
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 123
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 124
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 125
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 126
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 127
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 128
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 129
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 130
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 131
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 132
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 133
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 134
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 135
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 137
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Could not find the language line "comment"
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 20
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: months C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 50
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 50
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: tax1 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 78
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 78
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: tax2 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 85
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 85
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: sales C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 92
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 92
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: purchases C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 98
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 98
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Undefined variable: tax3 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 114
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 114
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 132
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 133
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:47 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 518
ERROR - 2016-08-22 17:24:47 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:24:48 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 105
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 115
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 116
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 117
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 118
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 119
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 120
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 121
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 122
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 123
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 124
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 125
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 126
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 127
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 128
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 129
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 130
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 131
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 132
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 133
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 134
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 135
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 137
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 105
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 115
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 116
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 117
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 118
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 119
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 120
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 121
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 122
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 123
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 124
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 125
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 126
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 127
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 128
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 129
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 130
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 131
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 132
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 133
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 134
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 135
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 137
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-08-22 17:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Could not find the language line "comment"
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:56 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 20
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: months C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 50
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 50
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: tax1 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 78
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 78
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: tax2 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 85
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 85
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: sales C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 92
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 92
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: purchases C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 98
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 98
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Undefined variable: tax3 C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 114
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 114
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 132
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 133
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 319
ERROR - 2016-08-22 17:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'bachatbags'@'localhost' (using password: YES) C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:24:57 --> Unable to connect to the database
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-08-22 17:24:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 518
ERROR - 2016-08-22 17:24:57 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:24:57 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:25:45 --> Could not find the language line "comment"
ERROR - 2016-08-22 17:25:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-22 17:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:25:55 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 17:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:25:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:25:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:25:59 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:25:59 --> 404 Page Not Found --> 
ERROR - 2016-08-22 17:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:26:10 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:10 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:10 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:10 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:26:10 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:26:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:26:11 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:11 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 17:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:26:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:26:19 --> You did not select a file to upload.
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:26:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:26:20 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:26:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:20 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 17:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:26:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:26:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:30:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:30:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:30:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:30:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:37:40 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:37:40 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:37:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:37:44 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:37:44 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 17:38:09 --> You did not select a file to upload.
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 17:38:09 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 17:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:38:09 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 17:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 17:38:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 17:38:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:07:39 --> You did not select a file to upload.
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:07:39 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:07:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:07:40 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 18:07:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:07:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:07:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:08:35 --> You did not select a file to upload.
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:08:35 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:08:35 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 18:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:10:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:10:22 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 18:10:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:10:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:10:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:11:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:11:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:11:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:11:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:23:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:23:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:23:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:26:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 788
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 789
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 834
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 835
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 836
ERROR - 2016-08-22 18:26:54 --> You did not select a file to upload.
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:26:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\bachatbag\sma\modules\products\controllers\products.php 877
ERROR - 2016-08-22 18:26:55 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\products\models\products_model.php 430
ERROR - 2016-08-22 18:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:55 --> Could not find the language line "ratings_details"
ERROR - 2016-08-22 18:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-22 18:26:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-22 18:26:57 --> Could not find the language line "pr_category_tip"
