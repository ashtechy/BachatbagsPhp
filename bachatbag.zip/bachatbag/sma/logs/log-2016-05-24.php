<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-24 09:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:31 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:31 --> Unable to connect to the database
ERROR - 2016-05-24 09:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:33 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:33 --> Unable to connect to the database
ERROR - 2016-05-24 09:52:33 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-05-24 09:52:33 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-05-24 09:52:33 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-05-24 09:52:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-05-24 09:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:35 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:35 --> Unable to connect to the database
ERROR - 2016-05-24 09:52:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:37 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 09:52:37 --> Unable to connect to the database
ERROR - 2016-05-24 09:52:37 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2016-05-24 09:52:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-05-24 09:52:37 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 87
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 88
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 89
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 90
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 91
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 98
ERROR - 2016-05-24 09:52:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 99
ERROR - 2016-05-24 09:52:38 --> 404 Page Not Found --> 
ERROR - 2016-05-24 12:23:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:26:10 --> Could not find the language line "comment"
ERROR - 2016-05-24 12:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:58:29 --> Could not find the language line "comment"
ERROR - 2016-05-24 12:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 12:59:06 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:00:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:00:12 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:00:39 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:03:31 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:03:46 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:04:21 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:04:23 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:04:39 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:05:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:05:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:05:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:05:32 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:05:52 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:05:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:05:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:05:55 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:05:58 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:06:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:06:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:06:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:06:18 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:06:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:06:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:06:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:06:34 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:06:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:06:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:06:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:06:36 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 140
ERROR - 2016-05-24 13:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 141
ERROR - 2016-05-24 13:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\auth\libraries\Ion_auth.php 142
ERROR - 2016-05-24 13:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:07:54 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:11:26 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:12:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:12:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:12:25 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:09 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:13:20 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:05 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:24:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:27:06 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:29:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:29:11 --> Could not find the language line "comment"
ERROR - 2016-05-24 13:29:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "description_header"
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "details"
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "header"
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "value"
ERROR - 2016-05-24 13:29:16 --> Could not find the language line "display_in_client_side"
ERROR - 2016-05-24 13:29:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:29:26 --> Could not find the language line "latitude"
ERROR - 2016-05-24 13:29:26 --> Could not find the language line "longitude"
ERROR - 2016-05-24 13:29:26 --> Could not find the language line "password"
ERROR - 2016-05-24 13:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:33:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:33:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:33:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:33:47 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:33:47 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:33:47 --> Could not find the language line "tin_number"
ERROR - 2016-05-24 13:33:47 --> Could not find the language line "dl_number"
ERROR - 2016-05-24 13:33:47 --> Could not find the language line "timings"
ERROR - 2016-05-24 13:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:34:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:34:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:34:08 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 13:39:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:39:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:39:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:39:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:39:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:39:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:39:27 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 13:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:42:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:42:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:42:09 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 13:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:45:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 13:45:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 13:45:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 14:48:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 14:48:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 14:48:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 14:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 14:55:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 14:55:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:02:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:02:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:02:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:10:57 --> Could not find the language line "comment"
ERROR - 2016-05-24 15:10:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:10:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:11:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:11:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:11:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:11:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:13:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:13:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:17:48 --> Severity: Notice  --> Use of undefined constant additional_data - assumed 'additional_data' C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 147
ERROR - 2016-05-24 15:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:18:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:19:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:24:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:24:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:24:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:24:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:24:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:24:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:24:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:25:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:27:30 --> Severity: Notice  --> Undefined property: CI::$identity_column C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:27:30 --> Severity: Notice  --> Undefined property: CI::$identity_column C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:27:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:30:30 --> Severity: Notice  --> Undefined variable: ip_address C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 182
ERROR - 2016-05-24 15:30:30 --> Severity: Notice  --> Undefined variable: ip_address C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 188
ERROR - 2016-05-24 15:30:30 --> Severity: Notice  --> Undefined variable: manual_activation C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 191
ERROR - 2016-05-24 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:33:56 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:33:56 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:34:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:34:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:34:03 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 15:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:41:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:12 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 15:41:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:41:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:13 --> Could not find the language line "select_user_role"
ERROR - 2016-05-24 15:41:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:41:17 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:17 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 15:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined property: CI::$store_salt C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined property: CI::$hash_method C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined property: CI::$store_salt C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined property: CI::$salt_length C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined property: CI::$salt_length C:\xampp\htdocs\computerrentals\system\core\Model.php 51
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined variable: ip_address C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 210
ERROR - 2016-05-24 15:41:39 --> Severity: Notice  --> Undefined variable: manual_activation C:\xampp\htdocs\computerrentals\sma\modules\suppliers\models\suppliers_model.php 219
ERROR - 2016-05-24 17:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:13:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:13:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:13:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:13:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:13:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:18:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:20:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:24:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 806
ERROR - 2016-05-24 17:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:26:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:26:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:26:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:26:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:27:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:27:22 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:29:29 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:29:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:29:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:29:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:29:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:30:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:33:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:33:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:33:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:33:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:33:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:33:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 806
ERROR - 2016-05-24 17:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:34:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 806
ERROR - 2016-05-24 17:36:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:37:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 806
ERROR - 2016-05-24 17:37:00 --> Severity: Notice  --> Undefined variable: default_group C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 811
ERROR - 2016-05-24 17:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:38:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:39:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 808
ERROR - 2016-05-24 17:39:39 --> Severity: Notice  --> Undefined variable: default_group C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 813
ERROR - 2016-05-24 17:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:40:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 808
ERROR - 2016-05-24 17:40:38 --> Severity: Notice  --> Undefined variable: default_group C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 815
ERROR - 2016-05-24 17:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:42:03 --> Severity: Notice  --> Undefined variable: default_group C:\xampp\htdocs\computerrentals\sma\modules\auth\models\ion_auth_model.php 815
ERROR - 2016-05-24 17:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:44:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:44:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:44:17 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:44:17 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:44:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:50:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:50:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:51:01 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:51:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:51:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:00 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:53:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:07 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:53:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-24 17:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "batch_no"
ERROR - 2016-05-24 17:53:27 --> Could not find the language line "expiredate"
ERROR - 2016-05-24 17:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:39 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:53:39 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:39 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:53:50 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:53:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:53:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:54:18 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:54:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:54:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:59:30 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:59:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:59:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:59:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 17:59:50 --> Could not find the language line "comment"
ERROR - 2016-05-24 17:59:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 17:59:50 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "comment"
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:01:36 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "comment"
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:01:43 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "comment"
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:01:55 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:02:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:02:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:02:04 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:02:04 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:02:04 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:12:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:12:57 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:14:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:14:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:14:16 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:14:16 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:14:16 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:16:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:16:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:16:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:16:03 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:16:03 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:16:03 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:16:08 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:16:53 --> 404 Page Not Found --> 
ERROR - 2016-05-24 18:17:30 --> 404 Page Not Found --> 
ERROR - 2016-05-24 18:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:17:35 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "vendors_added"
ERROR - 2016-05-24 18:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "vendors"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "vendors"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:18:19 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:20:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "vendors"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "vendors"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:20:11 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:20:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "comment"
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "list_vendors"
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "new_vendors"
ERROR - 2016-05-24 18:21:01 --> Could not find the language line "add_vendors_by_csv"
ERROR - 2016-05-24 18:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-24 18:41:30 --> Could not find the language line "comment"
ERROR - 2016-05-24 18:41:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:41:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-24 18:41:30 --> Could not find the language line "list_vendors"
