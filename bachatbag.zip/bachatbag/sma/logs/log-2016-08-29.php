<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-29 10:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-29 10:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-29 10:39:56 --> Could not find the language line "comment"
ERROR - 2016-08-29 10:39:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-29 10:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-29 10:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-29 10:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-29 10:40:05 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\bachatbag\sma\modules\sales\views\view_invoice.php 13
ERROR - 2016-08-29 10:40:05 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\bachatbag\sma\modules\sales\views\view_invoice.php 13
ERROR - 2016-08-29 10:40:05 --> 404 Page Not Found --> 
