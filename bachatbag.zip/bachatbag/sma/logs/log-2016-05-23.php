<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-23 16:45:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:45:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:46:59 --> Could not find the language line "comment"
ERROR - 2016-05-23 16:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-23 16:47:17 --> Could not find the language line "select_user_role"
