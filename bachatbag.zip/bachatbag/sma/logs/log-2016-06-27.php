<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-27 11:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:01 --> Could not find the language line "comment"
ERROR - 2016-06-27 11:36:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:16 --> Could not find the language line "comment"
ERROR - 2016-06-27 11:36:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:19 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:19 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:21 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:36:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:36:26 --> Severity: Notice  --> Undefined property: stdClass::$consult_doctor_name C:\xampp\htdocs\octbell\sma\modules\customers\views\edit.php 77
ERROR - 2016-06-27 11:36:26 --> Could not find the language line "consult_doctor_name"
ERROR - 2016-06-27 11:36:26 --> Could not find the language line "consult_doctor_name"
ERROR - 2016-06-27 11:37:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:37:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:37:46 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:37:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:37:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:53:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:53:49 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:55:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:55:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:56:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:56:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:56:55 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 11:57:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 11:57:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:11 --> Could not find the language line "comment"
ERROR - 2016-06-27 12:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:25 --> Could not find the language line "comment"
ERROR - 2016-06-27 12:07:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:42 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-27 12:07:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-27 12:07:44 --> Could not find the language line "list_service_request"
