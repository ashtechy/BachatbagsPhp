<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-19 12:08:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:08:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:08:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:08:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:08:58 --> Could not find the language line "comment"
ERROR - 2016-08-19 12:08:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 12:09:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:09:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 12:09:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 12:10:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:10:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:11:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:11:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:19:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:20:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:23:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:24:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 12:24:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 12:24:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 12:24:42 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 14:11:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:15 --> Could not find the language line "comment"
ERROR - 2016-08-19 14:11:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 14:11:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:11:46 --> Could not find the language line "category_details"
ERROR - 2016-08-19 14:12:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:12:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:12:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: BODY /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: BODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: -1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1150
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 247
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: BODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: -1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1150
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1003
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1003
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H1>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H1>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TABLE>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: THEAD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: THEAD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: THEAD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TBODY /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TBODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TBODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 0 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:06 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:06 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:08 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-19 14:12:12 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-19 14:12:12 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-19 14:12:12 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 27505
ERROR - 2016-08-19 14:12:13 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 27608
ERROR - 2016-08-19 14:12:13 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 9158
ERROR - 2016-08-19 14:14:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:14:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 14:14:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 14:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 15:21:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 15:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 15:21:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 15:21:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 15:21:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 15:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 15:21:55 --> Could not find the language line "August"
ERROR - 2016-08-19 15:22:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 15:22:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 15:22:01 --> Could not find the language line "comment"
ERROR - 2016-08-19 15:22:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 16:30:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:30:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "comment"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "edit_ann"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "catalog"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "add_catalog"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "list_catalog"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "channelpartner"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "list_partner"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "new_partner"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "add_partner_by_csv"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "print_barcodes"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "print_labels"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "loyaltypoints"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "monthly_sales_purchases"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "sp_tax"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "pp_tax"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "by_price"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "by_cost"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "best_sellers"
ERROR - 2016-08-19 16:30:20 --> Could not find the language line "total_sold"
ERROR - 2016-08-19 16:30:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 16:30:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:30:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:30:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:30:28 --> Could not find the language line "comment"
ERROR - 2016-08-19 16:30:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 16:31:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 16:31:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 16:31:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/controllers/sales.php 1332
ERROR - 2016-08-19 16:31:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/controllers/sales.php 1332
ERROR - 2016-08-19 16:31:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:44 --> Could not find the language line "category_details"
ERROR - 2016-08-19 16:31:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:54 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 16:31:54 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 16:31:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:31:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:31:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:32:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:32:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:32:00 --> Severity: Notice  --> Undefined property: stdClass::$batch_no /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/controllers/sales.php 1311
ERROR - 2016-08-19 16:32:00 --> Severity: Notice  --> Undefined property: stdClass::$expiredate /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/controllers/sales.php 1312
ERROR - 2016-08-19 16:33:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:33:59 --> Severity: Warning  --> filemtime(): stat failed for sma_db_backup.sql /home/vsgappshoppee/public_html/bachatbag/system/libraries/Zip.php 91
ERROR - 2016-08-19 16:42:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:42:04 --> Could not find the language line "catallog"
ERROR - 2016-08-19 16:42:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:42:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:42:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:43:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 16:44:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 16:44:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:19:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:19:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:19:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:21:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:50:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:50:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:50:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:50:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:50:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:50:59 --> Could not find the language line "comment"
ERROR - 2016-08-19 17:50:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 17:51:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:51:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:51:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:51:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 17:51:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 17:51:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:51:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:52:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:52:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:52:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:52:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:53:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:53:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 17:53:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 17:56:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:56:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:56:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:56:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:56:30 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 5
ERROR - 2016-08-19 17:57:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:57:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:58:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 17:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 17:58:02 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 5
ERROR - 2016-08-19 18:34:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:14 --> Severity: Notice  --> Undefined property: stdClass::$status /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/view_invoice.php 13
ERROR - 2016-08-19 18:34:14 --> Severity: Notice  --> Undefined property: stdClass::$status /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/view_invoice.php 13
ERROR - 2016-08-19 18:34:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:34:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:34:36 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 18:34:36 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 18:38:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:38:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 18:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 18:38:20 --> Could not find the language line "comment"
ERROR - 2016-08-19 18:38:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-19 19:42:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 19:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 20:48:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 20:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:01:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:01:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:01:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:01:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:01:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:03:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:03:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 6 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 6 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 6 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 6 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 7 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 7 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 7 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 7 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 8 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 8 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 8 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 8 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 9 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 9 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 9 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 9 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 10 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 10 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 10 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 10 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 11 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 472
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 11 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 473
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 11 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 474
ERROR - 2016-08-19 21:05:16 --> Severity: Notice  --> Undefined offset: 11 /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-19 21:05:16 --> You did not select a file to upload.
ERROR - 2016-08-19 21:05:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:05:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:07:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:07:48 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 5
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:07:48 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_cate.php 85
ERROR - 2016-08-19 21:08:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:08:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:08:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:15:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:15:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:15:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:35:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:36:00 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 21:36:00 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 21:36:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:36:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:36:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:36:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:36:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:37:18 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/edit_damage.php 25
ERROR - 2016-08-19 21:37:18 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/edit_damage.php 29
ERROR - 2016-08-19 21:37:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:38:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:38:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:38:21 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 21:38:21 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-19 21:40:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:40:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:40:19 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:40:19 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:41:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:41:19 --> Could not find the language line "catallog"
ERROR - 2016-08-19 21:41:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:41:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:41:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:41:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:41:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:46:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:46:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:46:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:46:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-19 21:48:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:48:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:48:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:48:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:48:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:49:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:49:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:49:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-19 21:49:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-19 21:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
