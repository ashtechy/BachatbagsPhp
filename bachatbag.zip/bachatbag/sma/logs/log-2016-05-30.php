<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-30 11:38:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:38:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:38:40 --> Could not find the language line "comment"
ERROR - 2016-05-30 11:38:40 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:38:40 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:38:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:38:49 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:38:49 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:38:49 --> Could not find the language line "select_user_role"
ERROR - 2016-05-30 11:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:38:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:38:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:39:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:39:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-30 11:39:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:39:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-30 11:39:23 --> Severity: Notice  --> Undefined property: stdClass::$consult_doctor_name C:\xampp\htdocs\octbell\sma\modules\customers\views\edit.php 77
ERROR - 2016-05-30 11:39:23 --> Could not find the language line "consult_doctor_name"
ERROR - 2016-05-30 11:39:23 --> Could not find the language line "consult_doctor_name"
