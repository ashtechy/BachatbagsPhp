<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-16 09:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 09:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 09:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 09:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 09:45:52 --> Could not find the language line "comment"
ERROR - 2016-06-16 09:45:52 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 09:45:52 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:03 --> Could not find the language line "comment"
ERROR - 2016-06-16 10:27:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:08 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-16 10:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-16 10:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-16 10:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:26 --> You did not select a file to upload.
ERROR - 2016-06-16 10:27:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-16 10:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:27:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:27:29 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-16 10:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:28:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-16 10:28:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:28:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-16 10:28:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
