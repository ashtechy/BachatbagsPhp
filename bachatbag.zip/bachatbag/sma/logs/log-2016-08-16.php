<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-16 10:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:51:02 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:51:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 12:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:51:47 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:51:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 12:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:51:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\pos\controllers\pos.php 518
ERROR - 2016-08-16 12:51:55 --> Could not find the language line "request_failed"
ERROR - 2016-08-16 12:51:55 --> Could not find the language line "customer_request_failed"
ERROR - 2016-08-16 12:51:56 --> 404 Page Not Found --> 
ERROR - 2016-08-16 12:53:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:53:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\pos\controllers\pos.php 518
ERROR - 2016-08-16 12:53:10 --> Could not find the language line "request_failed"
ERROR - 2016-08-16 12:53:10 --> Could not find the language line "customer_request_failed"
ERROR - 2016-08-16 12:53:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:53:14 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:53:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 12:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:54:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:54:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:54:34 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 12:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:56:24 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:56:24 --> Could not find the language line "loyaltypoints"
ERROR - 2016-08-16 12:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 12:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-16 12:57:11 --> Could not find the language line "comment"
ERROR - 2016-08-16 12:57:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-16 13:22:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:22:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:22:21 --> Unable to select database: bachatbag
ERROR - 2016-08-16 13:23:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:23:35 --> Unable to select database: bachatbag
ERROR - 2016-08-16 13:29:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:29:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:29:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:29:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:30:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:30:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:30:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:30:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:30:47 --> Could not find the language line "comment"
ERROR - 2016-08-16 13:30:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 13:31:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:31:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:31:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:33:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:33:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:33:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:33:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:42:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:42:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:42:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:42:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:42:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:42:56 --> Could not find the language line "comment"
ERROR - 2016-08-16 13:42:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 13:52:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:52:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:52:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:52:14 --> Could not find the language line "comment"
ERROR - 2016-08-16 13:52:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 13:54:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:23 --> Could not find the language line "category_has_subcategory"
ERROR - 2016-08-16 13:54:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:28 --> Could not find the language line "category_has_subcategory"
ERROR - 2016-08-16 13:54:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:35 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:54:35 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:54:35 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:54:35 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:54:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:43 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:54:43 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:54:43 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:54:43 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:54:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:54:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:54:57 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:54:57 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:54:57 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:54:57 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:55:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:06 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:55:06 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:55:06 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:55:06 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:55:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:37 --> Could not find the language line "category_has_subcategory"
ERROR - 2016-08-16 13:55:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:55:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:56:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:56:26 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:56:26 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:56:26 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:56:26 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:58:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:58:55 --> The path to the image is not correct.
ERROR - 2016-08-16 13:58:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-16 13:58:55 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:58:55 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:58:59 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:58:59 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:59:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:09 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:59:09 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:59:09 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:59:09 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:59:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:17 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 29
ERROR - 2016-08-16 13:59:17 --> Severity: Notice  --> Undefined property: stdClass::$front_catalog /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 60
ERROR - 2016-08-16 13:59:17 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 70
ERROR - 2016-08-16 13:59:17 --> Severity: Notice  --> Undefined property: stdClass::$front_navi /home/vsgappshoppee/public_html/bachatbag/sma/modules/categories/views/edit.php 91
ERROR - 2016-08-16 13:59:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 13:59:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 13:59:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:00:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:00:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:00:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:00:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:01:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:02:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:02:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:03:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:03:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:03:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:03:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:03:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:03:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:03:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 14:03:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/edit.php 191
ERROR - 2016-08-16 14:03:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 14:03:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/edit.php 200
ERROR - 2016-08-16 14:04:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/sheet_view.php 39
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:07:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:07:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 14:07:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/add.php 198
ERROR - 2016-08-16 14:07:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 14:07:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:07:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:07:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:07:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:36:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:36:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:37:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:41:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:41:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:41:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:48:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:48:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 14:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 14:48:53 --> Could not find the language line "comment"
ERROR - 2016-08-16 14:48:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 16:37:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 16:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 16:40:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 16:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 16:40:12 --> Severity: Notice  --> Undefined variable: role /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/controllers/auth.php 463
ERROR - 2016-08-16 16:40:12 --> Severity: Notice  --> Undefined variable: role /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/controllers/auth.php 463
ERROR - 2016-08-16 16:40:12 --> Could not find the language line "select_user_role"
ERROR - 2016-08-16 17:08:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 17:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 17:54:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 17:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 17:54:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 17:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 17:54:12 --> Could not find the language line "comment"
ERROR - 2016-08-16 17:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 18:48:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:48:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:29 --> Could not find the language line "comment"
ERROR - 2016-08-16 18:52:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 18:52:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:52:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:53:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:53:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:53:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:53:39 --> Could not find the language line "comment"
ERROR - 2016-08-16 18:53:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 18:54:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:54:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:54:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:54:43 --> Could not find the language line "catallog"
ERROR - 2016-08-16 18:54:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:54:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:54:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:55:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:55:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:56:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:56:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 18:56:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/add.php 198
ERROR - 2016-08-16 18:56:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 18:58:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:59:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:59:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:59:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:59:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:59:33 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:33 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: BODY /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined index: BODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:33 --> Severity: Notice  --> Undefined offset: -1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1150
ERROR - 2016-08-16 18:59:33 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:33 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 247
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: T /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 553
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: R /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 554
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: B /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 555
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: L /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 556
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: BODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: -1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1150
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31196
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 31205
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14374
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14375
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: MARKS /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 14376
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1003
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1003
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>>WRAP /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ROW-FLUID /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TEXT-CENTER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>CLASS>>INV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: H3>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-BORDERED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-HOVER /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TABLE>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: THEAD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: THEAD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: THEAD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TH>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TBODY /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TBODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TBODY>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TR>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: TD>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 0 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 4 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined offset: 5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 26572
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN12 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 969
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPAN5 /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1007
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 966
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: P>>ID>> /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/classes/cssmgr.php 1011
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined index: outline-s /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 3892
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 96
ERROR - 2016-08-16 18:59:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/includes/functions.php 97
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 27505
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 27608
ERROR - 2016-08-16 18:59:34 --> Severity: Notice  --> Undefined property: mPDF::$hasOC /home/vsgappshoppee/public_html/bachatbag/sma/libraries/MPDF/mpdf.php 9158
ERROR - 2016-08-16 18:59:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 18:59:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 18:59:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:00:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:00:08 --> Severity: Notice  --> Undefined variable: warehouses /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-16 19:00:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-16 19:00:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:00:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:00:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:00:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:00:37 --> Severity: Notice  --> Undefined variable: role /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/controllers/auth.php 463
ERROR - 2016-08-16 19:00:37 --> Severity: Notice  --> Undefined variable: role /home/vsgappshoppee/public_html/bachatbag/sma/modules/auth/controllers/auth.php 463
ERROR - 2016-08-16 19:00:37 --> Could not find the language line "select_user_role"
ERROR - 2016-08-16 19:01:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:01:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:01:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:08:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:08:30 --> Could not find the language line "catallog"
ERROR - 2016-08-16 19:08:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:08:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:08:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:08:51 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 19:08:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/add.php 198
ERROR - 2016-08-16 19:08:51 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 19:17:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/sheet_view.php 39
ERROR - 2016-08-16 19:17:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:17:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:18:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:18:00 --> Could not find the language line "comment"
ERROR - 2016-08-16 19:18:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-16 19:18:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:18:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 19:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/add.php 198
ERROR - 2016-08-16 19:18:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-16 19:19:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:19:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:19:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:20:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:20:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:20:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:20:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 19:20:18 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/details.php 63
ERROR - 2016-08-16 19:20:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 19:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:00:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:00:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:00:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:23:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:23:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:23:10 --> Severity: Notice  --> Undefined variable: warehouses /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-16 21:23:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-16 21:23:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:26:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-16 21:27:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-16 21:27:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
