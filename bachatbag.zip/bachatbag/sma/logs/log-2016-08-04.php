<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-04 11:37:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:37:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:37:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:37:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:37:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:37:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:37:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:37:34 --> Could not find the language line "comment"
ERROR - 2016-08-04 11:37:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:37:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:37:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 11:37:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:37:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:37:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:37:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 11:37:43 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 11:38:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:39:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:39:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:39:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:39:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:39:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:51:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 11:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 11:51:06 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:51:06 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 11:51:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 11:51:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:20:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:20:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:20:24 --> Could not find the language line "comment"
ERROR - 2016-08-04 12:20:24 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:20:24 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:20:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 12:20:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:20:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:23:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:23:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:23:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:23:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:23:45 --> Could not find the language line "comment"
ERROR - 2016-08-04 12:23:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:23:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:23:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 12:24:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:24:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:24:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:24:12 --> Could not find the language line "comment"
ERROR - 2016-08-04 12:24:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:24:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:24:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 12:24:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:24:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:24:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:24:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:24:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:24:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:26:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:26:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:26:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:26:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:26:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:38:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:38:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:38:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:38:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:38:33 --> Could not find the language line "comment"
ERROR - 2016-08-04 12:38:33 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:38:33 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:38:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 12:39:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:39:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:39:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:39:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:39:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:39:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:39:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:39:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:43:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:43:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:43:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:43:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:43:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:43:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:44:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:44:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:44:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:44:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:44:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:45:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:45:19 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:45:19 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:45:19 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-04 12:45:19 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-04 12:46:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:49:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:49:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:49:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:49:26 --> Severity: Notice  --> Undefined variable: warehouses /home/vsgappshoppee/public_html/octobell/admin/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-04 12:49:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/sales/views/deliveries.php 112
ERROR - 2016-08-04 12:49:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:49:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:49:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:49:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:49:42 --> Could not find the language line "select_user_role"
ERROR - 2016-08-04 12:51:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:51:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:51:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:51:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:51:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:53:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:53:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:53:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:53:29 --> Could not find the language line "select_user_role"
ERROR - 2016-08-04 12:53:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:53:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:53:58 --> Could not find the language line "comment"
ERROR - 2016-08-04 12:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:53:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 12:54:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:54:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:54:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:54:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:54:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:58:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 12:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 12:58:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:58:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 12:58:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 12:58:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 13:01:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:01:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:04:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:04:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 458
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 459
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 460
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 461
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 462
ERROR - 2016-08-04 13:04:20 --> You did not select a file to upload.
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 476
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 458
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 459
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 460
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 461
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 462
ERROR - 2016-08-04 13:04:20 --> You did not select a file to upload.
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Undefined offset: 2 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 476
ERROR - 2016-08-04 13:04:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 13:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 13:04:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:08:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:08:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 13:08:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 13:08:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 13:08:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 13:08:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-04 13:26:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:26:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 13:26:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 13:26:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 14:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 14:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 14:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 14:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:45 --> Could not find the language line "comment"
ERROR - 2016-08-04 14:42:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 14:42:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 14:42:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-04 14:42:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 14:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 14:42:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 14:42:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-04 14:42:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 14:42:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-04 16:04:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 16:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 16:38:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 16:38:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 16:38:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 16:38:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 18:04:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 18:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-04 18:04:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-04 18:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
