<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-29 09:53:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 09:53:56 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:00:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:00:14 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:00:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:00:15 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:00:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:00:38 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:00:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:00:49 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:00:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:00:50 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:02:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:02:52 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:05:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:05:00 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:05:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:05:07 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:06:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:06:11 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:06:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:06:14 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:11:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:11:22 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:13:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:13:02 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:18:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:18:37 --> 404 Page Not Found --> 
ERROR - 2016-06-29 10:18:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 10:18:39 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:23:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:23:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:23:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:24:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:24:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:24:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:24:09 --> Could not find the language line "comment"
ERROR - 2016-06-29 11:24:10 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:24:10 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:24:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:24:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:24:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:33:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:33:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:33:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:34:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:34:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:34:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:36:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:36:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:36:00 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:36:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:36:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:36:15 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:36:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:36:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:37:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:37:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:37:03 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:40:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:40:11 --> The path to the image is not correct.
ERROR - 2016-06-29 11:40:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-29 11:40:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:40:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:40:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:40:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:40:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:40:13 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:40:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:40:13 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:45:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:45:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:45:02 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:45:27 --> The path to the image is not correct.
ERROR - 2016-06-29 11:45:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-29 11:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:45:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:45:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:27 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:45:27 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:46:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:46:19 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:19 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:46:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:46:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:46:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:27 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:46:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:27 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:46:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:46:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:46:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:47:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:47:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:47:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:48:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:48:22 --> The path to the image is not correct.
ERROR - 2016-06-29 11:48:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-06-29 11:48:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:48:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:48:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:48:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:48:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:48:22 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:48:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:48:22 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:49:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:49:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:49:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:49:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 11:49:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 11:49:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:49:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:49:53 --> You did not select a file to upload.
ERROR - 2016-06-29 11:49:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:49:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:49:53 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:49:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:49:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:49:59 --> 404 Page Not Found --> 
ERROR - 2016-06-29 11:51:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 11:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 11:51:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:51:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 11:51:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 11:51:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 11:51:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-06-29 11:51:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-06-29 11:51:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-06-29 12:27:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:27:52 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:27:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:27:52 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:34:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:34:25 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:35:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:35:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:35:36 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:35:36 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:35:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:35:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:35:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:35:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:35:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:35:44 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 12:35:44 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-29 12:36:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:36:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:36:31 --> You did not select a file to upload.
ERROR - 2016-06-29 12:36:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:36:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:36:32 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:36:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:36:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:35 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:36:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:36 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:36:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:40 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:36:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:36:42 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:37:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:37:40 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:37:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:37:43 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:38:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:38:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:38:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:38:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:38:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:38:25 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:38:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:38:25 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:38:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:38:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:38:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:38:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:39:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:39:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:39:18 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:41:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:41:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:41:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:41:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:42:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:42:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:42:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:42:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:42:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:42:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 12:42:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:42:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 12:42:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:42:02 --> 404 Page Not Found --> 
ERROR - 2016-06-29 12:42:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 12:42:02 --> 404 Page Not Found --> 
ERROR - 2016-06-29 13:10:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 13:10:43 --> 404 Page Not Found --> 
ERROR - 2016-06-29 13:10:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 13:10:43 --> 404 Page Not Found --> 
ERROR - 2016-06-29 14:45:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 14:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 14:46:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 14:46:08 --> 404 Page Not Found --> 
ERROR - 2016-06-29 14:49:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 14:49:19 --> 404 Page Not Found --> 
ERROR - 2016-06-29 14:49:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 14:49:20 --> 404 Page Not Found --> 
ERROR - 2016-06-29 14:59:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 14:59:13 --> 404 Page Not Found --> 
ERROR - 2016-06-29 15:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 15:02:50 --> 404 Page Not Found --> 
ERROR - 2016-06-29 15:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 15:02:50 --> 404 Page Not Found --> 
ERROR - 2016-06-29 16:17:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:17:13 --> 404 Page Not Found --> 
ERROR - 2016-06-29 16:17:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:17:24 --> 404 Page Not Found --> 
ERROR - 2016-06-29 16:18:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:18:42 --> 404 Page Not Found --> 
ERROR - 2016-06-29 16:18:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:18:42 --> 404 Page Not Found --> 
ERROR - 2016-06-29 16:59:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 16:59:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 16:59:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-29 16:59:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 16:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-29 17:14:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:14:19 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:14:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:14:20 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:15:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:15:27 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:15:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:15:38 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:17:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:17:16 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:17:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:17:18 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:18:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:18:29 --> 404 Page Not Found --> 
ERROR - 2016-06-29 17:18:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-06-29 17:18:29 --> 404 Page Not Found --> 
