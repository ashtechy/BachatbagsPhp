<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-29 17:34:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:34:46 --> 404 Page Not Found --> 
ERROR - 2016-07-29 17:34:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:34:48 --> 404 Page Not Found --> 
ERROR - 2016-07-29 17:34:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:34:57 --> 404 Page Not Found --> 
ERROR - 2016-07-29 17:34:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:34:57 --> 404 Page Not Found --> 
ERROR - 2016-07-29 17:35:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:35:02 --> 404 Page Not Found --> 
ERROR - 2016-07-29 17:35:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-29 17:35:02 --> 404 Page Not Found --> 
