<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-01 10:14:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:14:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-01 10:22:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:22:13 --> 404 Page Not Found --> 
ERROR - 2016-07-01 10:22:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:22:38 --> 404 Page Not Found --> 
ERROR - 2016-07-01 10:22:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:22:38 --> 404 Page Not Found --> 
ERROR - 2016-07-01 10:25:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:25:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-01 10:27:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:27:37 --> 404 Page Not Found --> 
ERROR - 2016-07-01 10:27:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 10:27:37 --> 404 Page Not Found --> 
ERROR - 2016-07-01 15:59:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 15:59:04 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:01:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:01:26 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:01:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:01:26 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:01:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:01:52 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:01:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:01:53 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:06:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:06:16 --> 404 Page Not Found --> 
ERROR - 2016-07-01 16:06:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-01 16:06:19 --> 404 Page Not Found --> 
