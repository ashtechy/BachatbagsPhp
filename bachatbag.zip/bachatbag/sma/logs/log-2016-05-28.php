<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-28 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-28 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-28 16:12:33 --> Could not find the language line "comment"
ERROR - 2016-05-28 16:12:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-28 16:12:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-28 16:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-28 16:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
