<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-21 11:03:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:03:57 --> 404 Page Not Found --> 
ERROR - 2016-07-21 11:03:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:03:59 --> 404 Page Not Found --> 
ERROR - 2016-07-21 11:06:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:06:07 --> 404 Page Not Found --> 
ERROR - 2016-07-21 11:06:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:06:07 --> 404 Page Not Found --> 
ERROR - 2016-07-21 11:07:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:07:37 --> 404 Page Not Found --> 
ERROR - 2016-07-21 11:07:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-21 11:07:38 --> 404 Page Not Found --> 
