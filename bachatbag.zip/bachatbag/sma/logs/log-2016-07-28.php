<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-28 10:18:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-28 10:18:54 --> 404 Page Not Found --> 
ERROR - 2016-07-28 10:18:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-28 10:18:55 --> 404 Page Not Found --> 
ERROR - 2016-07-28 10:37:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-28 10:37:00 --> 404 Page Not Found --> 
ERROR - 2016-07-28 10:46:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-28 10:46:08 --> 404 Page Not Found --> 
