<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-23 09:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:39 --> Could not find the language line "comment"
ERROR - 2016-08-23 09:55:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\bachatbag\sma\modules\home\views\content.php 188
ERROR - 2016-08-23 09:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:55:59 --> Could not find the language line "catallog"
ERROR - 2016-08-23 09:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:56:02 --> 404 Page Not Found --> 
ERROR - 2016-08-23 09:56:02 --> 404 Page Not Found --> 
ERROR - 2016-08-23 09:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:56:09 --> Could not find the language line "catallog"
ERROR - 2016-08-23 09:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\bachatbag\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-23 09:56:09 --> 404 Page Not Found --> 
ERROR - 2016-08-23 09:56:09 --> 404 Page Not Found --> 
