<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-25 09:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 09:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 09:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 09:48:03 --> Could not find the language line "comment"
ERROR - 2016-05-25 09:48:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 09:48:03 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 09:48:03 --> Could not find the language line "list_vendors"
ERROR - 2016-05-25 10:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 10:16:41 --> Could not find the language line "comment"
ERROR - 2016-05-25 10:16:41 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:16:41 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:16:41 --> Could not find the language line "list_vendors"
ERROR - 2016-05-25 10:17:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 10:17:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:17:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:17:24 --> Could not find the language line "list_vendors"
ERROR - 2016-05-25 10:17:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 10:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 10:17:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:17:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:17:38 --> Could not find the language line "list_vendors"
ERROR - 2016-05-25 10:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 10:19:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 10:19:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:00:32 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:00:32 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:04:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:04:13 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:05:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:05:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:05:21 --> Could not find the language line "consult_doctor_name"
ERROR - 2016-05-25 11:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:05:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:05:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:06:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:06:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "categorgy"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "dl_number"
ERROR - 2016-05-25 11:07:05 --> Could not find the language line "timings"
ERROR - 2016-05-25 14:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "categorgy"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "dl_number"
ERROR - 2016-05-25 14:04:29 --> Could not find the language line "timings"
ERROR - 2016-05-25 14:23:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "categorgy"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "dl_number"
ERROR - 2016-05-25 14:23:04 --> Could not find the language line "timings"
ERROR - 2016-05-25 14:23:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:23:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:23:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:23:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:23:46 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:23:46 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:25:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:25:11 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:26:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:26:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:26:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:26:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:28:20 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:28:20 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:30:47 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:30:47 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:30:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:31:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:31:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:31:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:31:54 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:54 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:33:49 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:33:49 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:35:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:35:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:35:16 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:35:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:35:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:36:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:36:51 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:36:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:36:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "batch_no"
ERROR - 2016-05-25 14:37:15 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 14:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:42:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:42:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:42:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 14:42:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:42:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:27 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:42:27 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 14:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:42:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:42:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:43:34 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:43:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:43:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:46:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:46:57 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:46:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:46:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:53:27 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:53:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:53:27 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:53:27 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 14:53:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:53:37 --> 404 Page Not Found --> settings/add_catalog
ERROR - 2016-05-25 14:54:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:54:57 --> 404 Page Not Found --> settings/add_catalog
ERROR - 2016-05-25 14:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:55:00 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:55:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:00 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 14:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:55:03 --> 404 Page Not Found --> settings/add_catalog
ERROR - 2016-05-25 14:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:55:37 --> Could not find the language line "comment"
ERROR - 2016-05-25 14:55:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:37 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:37 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 14:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 14:55:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 14:55:44 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:09:38 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:09:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:09:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:09:45 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:09:45 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:09:45 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:09:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:09:46 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:09:46 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:10:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:10:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:10:57 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:10:57 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:10:57 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:11:02 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "catalog_added"
ERROR - 2016-05-25 15:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:11:14 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:11:14 --> 404 Page Not Found --> settings/getdatatableajax
ERROR - 2016-05-25 15:11:14 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:11:14 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:15:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:15:08 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:15:08 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:15:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:15:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:15:08 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:15:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:15:09 --> Could not find the language line "edit_catalog"
ERROR - 2016-05-25 15:15:09 --> Could not find the language line "alert_x_catalog"
ERROR - 2016-05-25 15:15:09 --> Could not find the language line "delete_catalog"
ERROR - 2016-05-25 15:15:09 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:15:09 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:15:14 --> Could not find the language line "edit_catalog"
ERROR - 2016-05-25 15:15:14 --> Could not find the language line "alert_x_catalog"
ERROR - 2016-05-25 15:15:14 --> Could not find the language line "delete_catalog"
ERROR - 2016-05-25 15:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:15:25 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:16:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "list_catalog"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:16:18 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "new_catalog"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "list_catalog"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:16:57 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "list_catalog"
ERROR - 2016-05-25 15:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "edit_catalog"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "alert_x_catalog"
ERROR - 2016-05-25 15:17:01 --> Could not find the language line "delete_catalog"
ERROR - 2016-05-25 15:17:02 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:17:02 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "catalog"
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:22:09 --> Could not find the language line "list_catalog"
ERROR - 2016-05-25 15:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:22:09 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:22:09 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:22:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:22:26 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:22:26 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:22:26 --> Could not find the language line "add_catalog"
ERROR - 2016-05-25 15:22:26 --> Could not find the language line "list_catalog"
ERROR - 2016-05-25 15:22:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:22:26 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:22:26 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:23:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:23:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:23:06 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:23:06 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:23:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:23:23 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:23:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:23:23 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:23:23 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:23:23 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:25:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:25:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:25:08 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:25:08 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:28:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:28:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:30:25 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:30:25 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:30:25 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:30:25 --> Could not find the language line "catalog_code"
ERROR - 2016-05-25 15:30:25 --> Could not find the language line "catalog_name"
ERROR - 2016-05-25 15:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:31:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:31:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:36:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:36:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:36:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:36:40 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:36:40 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:36:40 --> Could not find the language line "catallog"
ERROR - 2016-05-25 15:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:36:40 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:36:40 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:33 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:44:33 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:44:33 --> Could not find the language line "catallog"
ERROR - 2016-05-25 15:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:33 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:33 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:48 --> 404 Page Not Found --> settings/edit
ERROR - 2016-05-25 15:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:50 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:50 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:44:51 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 15:44:51 --> Could not find the language line "catallog"
ERROR - 2016-05-25 15:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:52 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:52 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:56 --> 404 Page Not Found --> settings/delete
ERROR - 2016-05-25 15:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 15:44:58 --> 404 Page Not Found --> 
ERROR - 2016-05-25 15:44:58 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:02:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:02:04 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:02:04 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:02:04 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:02:04 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:02:31 --> Could not find the language line "catalog_deleted"
ERROR - 2016-05-25 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:02:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:02:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:02:31 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:02:32 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:02:32 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:07 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:07 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:04:07 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:21 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:21 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:04:21 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:04:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:38 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:04:38 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:07:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:07:15 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:07:15 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:07:15 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:08:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:08:29 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:08:29 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:08:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:08:57 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:08:57 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:08:57 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:08:57 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:08:59 --> Severity: Notice  --> Undefined property: CI::$categories_model C:\xampp\htdocs\computerrentals\sma\third_party\MX\Controller.php 59
ERROR - 2016-05-25 16:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:13:41 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:13:41 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:13:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:13:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:13:42 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:13:42 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:13:42 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:13:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:13:56 --> Could not find the language line "update_catalog"
ERROR - 2016-05-25 16:13:56 --> Could not find the language line "update_catalog"
ERROR - 2016-05-25 16:13:56 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:13:56 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:13:56 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:13:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:13:56 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:13:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:13:56 --> Could not find the language line "update_catalog"
ERROR - 2016-05-25 16:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:14:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:14:43 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:14:43 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:14:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:14:43 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:14:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:02 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:02 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:03 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:15:03 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:15:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:07 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:07 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 15
ERROR - 2016-05-25 16:15:07 --> Severity: Notice  --> Undefined variable: category C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:15:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\computerrentals\sma\modules\settings\views\edit_catalog.php 19
ERROR - 2016-05-25 16:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:21 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:21 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:21 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:15:21 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:24 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:15:24 --> Could not find the language line "catallog"
ERROR - 2016-05-25 16:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:15:25 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:15:25 --> 404 Page Not Found --> 
ERROR - 2016-05-25 16:16:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:16:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:16:19 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:16:19 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:21:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:21:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:21:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:21:22 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:21:22 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:21:22 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:33:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:33:55 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:34:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:05 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:34:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:06 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:34:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:34:42 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:34:42 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:34:42 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:35:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:35:09 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:35:09 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:35:09 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:35:09 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:35:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:35:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:35:10 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:35:10 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:35:10 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:36:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:36:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:36:34 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:36:34 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:36:34 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:36:34 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:38:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:38:16 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:38:16 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:38:16 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:38:16 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:39:14 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:39:14 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:39:14 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:39:14 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:39:14 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:39:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:39:44 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:39:44 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:39:44 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:39:44 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:40:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:40:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:40:00 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:40:00 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:40:00 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:40:00 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:50:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:50:22 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:50:22 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:50:22 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:50:22 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:56:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:56:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:56:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:56:30 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:56:30 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:56:30 --> Could not find the language line "vendor"
ERROR - 2016-05-25 16:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 16:58:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:58:12 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 16:58:13 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 16:58:13 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 16:58:13 --> Could not find the language line "vendor"
ERROR - 2016-05-25 17:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:00:42 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 17:00:42 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 17:00:42 --> Could not find the language line "vendor"
ERROR - 2016-05-25 17:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:01:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:01:30 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:01:30 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 17:01:30 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 17:01:30 --> Could not find the language line "vendor"
ERROR - 2016-05-25 17:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:03:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:03:10 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:03:10 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 17:03:10 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 17:03:10 --> Could not find the language line "vendor"
ERROR - 2016-05-25 17:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:03:58 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:03:58 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:04:39 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:04:39 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:04:39 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 17:04:39 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 17:04:39 --> Could not find the language line "vendor"
ERROR - 2016-05-25 17:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:05:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:05:08 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\computerrentals\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:05:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:05:31 --> Could not find the language line "list_service_request"
ERROR - 2016-05-25 17:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:32:40 --> Could not find the language line "comment"
ERROR - 2016-05-25 17:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:51:38 --> Could not find the language line "comment"
ERROR - 2016-05-25 17:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:56:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:57:15 --> Could not find the language line "comment"
ERROR - 2016-05-25 17:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:57:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 17:58:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 17:58:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:09:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:10:30 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:10:31 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:10:31 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:13:03 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:13:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:13:04 --> Severity: Notice  --> Undefined index: id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:15:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:15:04 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:15:05 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:29:42 --> Severity: Notice  --> Undefined index: session_id C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 335
ERROR - 2016-05-25 18:32:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:32:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:32:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:32:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:33:27 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:34:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:37:24 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:51:23 --> Could not find the language line "comment"
ERROR - 2016-05-25 18:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:52:58 --> Could not find the language line "select_user_role"
ERROR - 2016-05-25 18:52:58 --> Could not find the language line "suppiler"
ERROR - 2016-05-25 18:52:58 --> Could not find the language line "vendor"
ERROR - 2016-05-25 18:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:27 --> Could not find the language line "comment"
ERROR - 2016-05-25 18:53:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:36 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:53:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "mrpprice"
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "mrpprice"
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "batch_no"
ERROR - 2016-05-25 18:54:21 --> Severity: Notice  --> Undefined property: stdClass::$batch_no C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 96
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "mrpprice"
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 18:54:21 --> Severity: Notice  --> Undefined property: stdClass::$expiredate C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 101
ERROR - 2016-05-25 18:54:21 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 18:54:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:54:33 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 18:54:33 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 18:54:33 --> Could not find the language line "batch_no"
ERROR - 2016-05-25 18:54:33 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 18:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 1332
ERROR - 2016-05-25 18:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:21 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 18:55:21 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 18:55:21 --> Could not find the language line "batch_no"
ERROR - 2016-05-25 18:55:21 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 18:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:25 --> Severity: Notice  --> Undefined property: stdClass::$batch_no C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 1311
ERROR - 2016-05-25 18:55:25 --> Severity: Notice  --> Undefined property: stdClass::$expiredate C:\xampp\htdocs\octbell\sma\modules\sales\controllers\sales.php 1312
ERROR - 2016-05-25 18:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:55:50 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\octbell\sma\modules\sales\views\view_invoice.php 13
ERROR - 2016-05-25 18:55:50 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\octbell\sma\modules\sales\views\view_invoice.php 13
ERROR - 2016-05-25 18:55:50 --> Severity: Notice  --> Undefined property: stdClass::$consult_doctor_name C:\xampp\htdocs\octbell\sma\modules\sales\views\view_invoice.php 38
ERROR - 2016-05-25 18:55:50 --> Could not find the language line "batch_no"
ERROR - 2016-05-25 18:55:50 --> Could not find the language line "expiredate"
ERROR - 2016-05-25 18:55:50 --> 404 Page Not Found --> 
ERROR - 2016-05-25 18:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:56:32 --> Could not find the language line "comment"
ERROR - 2016-05-25 18:56:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:56:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 18:59:32 --> Could not find the language line "comment"
ERROR - 2016-05-25 19:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:00:19 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 19:00:19 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 19:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:01:43 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 19:01:43 --> Could not find the language line "no_suggestions"
ERROR - 2016-05-25 19:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:02:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-05-25 19:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:05:37 --> Could not find the language line "comment"
ERROR - 2016-05-25 19:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:05:52 --> Could not find the language line "tin_number"
ERROR - 2016-05-25 19:05:52 --> Could not find the language line "dl_number"
ERROR - 2016-05-25 19:05:52 --> Could not find the language line "timings"
ERROR - 2016-05-25 19:06:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-25 19:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
