<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-19 10:00:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:00:34 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:05:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:05:13 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:05:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:05:32 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:05:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:05:32 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:05:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:05:45 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:05:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:05:45 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:06:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:09 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:06:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:19 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:06:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:45 --> Could not find the language line "comment"
ERROR - 2016-07-19 10:06:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:06:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:06:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-19 10:06:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:06:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:06:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:06:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:07:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:07:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:07:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:07:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:07:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:07:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-19 10:07:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 729
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 731
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 729
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 731
ERROR - 2016-07-19 10:07:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:07:08 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:07:08 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:07:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:07:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:07:59 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:08:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:08:34 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:09:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:09:26 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:09:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:09:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:09:57 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:09:57 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:09:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:09:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:09:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 729
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 731
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 729
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 731
ERROR - 2016-07-19 10:10:08 --> You did not select a file to upload.
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:10:08 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:10:08 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:10:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:10:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:10:10 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:10:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:10:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:10:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:10:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:10:17 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-19 10:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 256
ERROR - 2016-07-19 10:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 322
ERROR - 2016-07-19 10:11:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:11:35 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:14:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:14:47 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:14:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:14:47 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:15:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:15:02 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:17:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:17:23 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:17:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:17:59 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:19:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:19:01 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:19:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:19:18 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:21:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:21:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:21:03 --> You did not select a file to upload.
ERROR - 2016-07-19 10:21:03 --> You did not select a file to upload.
ERROR - 2016-07-19 10:21:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-07-19 10:21:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:21:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:21:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:21:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:24:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:24:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:24:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:24:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:24:46 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-19 10:24:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-19 10:24:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 256
ERROR - 2016-07-19 10:24:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 322
ERROR - 2016-07-19 10:24:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:24:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:24:49 --> You did not select a file to upload.
ERROR - 2016-07-19 10:24:49 --> You did not select a file to upload.
ERROR - 2016-07-19 10:24:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-07-19 10:24:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:24:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:24:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:24:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:34 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:33:34 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:33:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:34 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:33:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:35 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:33:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:33:56 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:33:56 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:04 --> The path to the image is not correct.
ERROR - 2016-07-19 10:34:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-19 10:34:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:04 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:34:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:04 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:34:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:27 --> The path to the image is not correct.
ERROR - 2016-07-19 10:34:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-19 10:34:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:28 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:34:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:28 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:34:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:41 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:41 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:49 --> The path to the image is not correct.
ERROR - 2016-07-19 10:34:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-19 10:34:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:49 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:49 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:34:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:34:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:49 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:34:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:34:49 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:35:13 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:35:13 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:35:13 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:35:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:35:13 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:49:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:49:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:49:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:49:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:49:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:49:24 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:49:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:49:24 --> 404 Page Not Found --> 
ERROR - 2016-07-19 10:49:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:49:33 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:49:33 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:50:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:50:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:50:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:53:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:53:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:56:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:56:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:56:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:56:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:56:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:56:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:56:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:59:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 10:59:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 10:59:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 10:59:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:01:25 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:25 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:01:49 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:49 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:01:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:01:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:54 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:01:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:54 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:01:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:01:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:01:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:01 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:01 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:02:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:05 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:05 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:07 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:07 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:08 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:02:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:08 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:02:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:09 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:09 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:39 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:39 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:39 --> Severity: Notice  --> Undefined variable: categories C:\xampp\htdocs\octobel_old\admin\sma\modules\categories\views\edit.php 29
ERROR - 2016-07-19 11:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:02:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:02:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:04:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:04:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:04:15 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:15 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:04:33 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:04:33 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:19 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:26 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:36 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:36 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:39 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:05:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:39 --> 404 Page Not Found --> 
ERROR - 2016-07-19 11:05:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 11:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 11:05:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 11:05:40 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 12:18:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 12:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 12:18:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 12:18:51 --> Could not find the language line "list_service_request"
ERROR - 2016-07-19 12:18:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 12:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 12:18:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 12:18:51 --> 404 Page Not Found --> 
ERROR - 2016-07-19 12:18:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 12:18:51 --> 404 Page Not Found --> 
ERROR - 2016-07-19 15:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 15:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 15:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 15:02:50 --> 404 Page Not Found --> 
ERROR - 2016-07-19 15:02:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 15:02:50 --> 404 Page Not Found --> 
ERROR - 2016-07-19 17:56:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 17:56:17 --> 404 Page Not Found --> 
ERROR - 2016-07-19 19:00:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 19:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-19 19:00:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-19 19:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
