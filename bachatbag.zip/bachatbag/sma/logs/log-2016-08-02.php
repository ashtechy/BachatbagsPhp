<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-02 10:35:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:35:03 --> 404 Page Not Found --> 
ERROR - 2016-08-02 10:35:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:35:34 --> 404 Page Not Found --> 
ERROR - 2016-08-02 10:35:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:35:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:35:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:35:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:36:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:36:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:36:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:36:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:36:11 --> Could not find the language line "comment"
ERROR - 2016-08-02 10:36:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:36:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-08-02 10:36:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:36:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:36:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:37:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:37:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:37:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:37:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:42:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:42:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:43:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:43:35 --> The path to the image is not correct.
ERROR - 2016-08-02 10:43:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-02 10:43:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:43:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:43:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:43:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:43:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:38 --> 404 Page Not Found --> 
ERROR - 2016-08-02 10:43:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:38 --> 404 Page Not Found --> 
ERROR - 2016-08-02 10:43:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:43:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:43:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:44:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:44:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:44:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:45:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:45:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:45:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:45:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:46:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:46:24 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:46:24 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:46:24 --> Severity: Notice  --> Undefined variable: nav_checked C:\xampp\htdocs\octobel_old\admin\sma\modules\categories\views\edit.php 53
ERROR - 2016-08-02 10:47:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 10:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 10:47:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 10:47:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:27:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:27:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:27:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:27:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:27:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:34:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:34:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:34:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:34:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:34:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:34:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-08-02 12:34:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:34:28 --> You did not select a file to upload.
ERROR - 2016-08-02 12:34:28 --> You did not select a file to upload.
ERROR - 2016-08-02 12:34:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-08-02 12:34:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:34:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:34:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:34:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:35:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:35:03 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:35:03 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:35:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:35:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:35:03 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-08-02 12:35:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:35:09 --> You did not select a file to upload.
ERROR - 2016-08-02 12:35:09 --> You did not select a file to upload.
ERROR - 2016-08-02 12:35:09 --> You did not select a file to upload.
ERROR - 2016-08-02 12:35:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-08-02 12:35:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:35:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:35:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:35:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:40:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:40:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:40:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:40:52 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:40:52 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 12:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-08-02 12:41:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:41:10 --> You did not select a file to upload.
ERROR - 2016-08-02 12:41:10 --> You did not select a file to upload.
ERROR - 2016-08-02 12:41:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 772
ERROR - 2016-08-02 12:41:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 12:41:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:41:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 12:41:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 12:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:04:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:04:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:04:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:04:35 --> Could not find the language line "comment"
ERROR - 2016-08-02 13:04:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:04:36 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-08-02 13:04:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:04:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:04:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:06:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:06:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:06:46 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:06:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:06:58 --> The path to the image is not correct.
ERROR - 2016-08-02 13:06:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-02 13:06:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:06:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:06:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 13:06:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 13:07:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:07:00 --> 404 Page Not Found --> 
ERROR - 2016-08-02 13:07:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 13:07:00 --> 404 Page Not Found --> 
ERROR - 2016-08-02 14:22:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 14:22:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 14:22:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 14:22:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:22:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-02 14:22:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:22:31 --> 404 Page Not Found --> 
ERROR - 2016-08-02 14:22:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:22:31 --> 404 Page Not Found --> 
ERROR - 2016-08-02 14:35:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:35:06 --> 404 Page Not Found --> 
ERROR - 2016-08-02 14:35:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-08-02 14:35:06 --> 404 Page Not Found --> 
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 14:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:48:03 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:48:03 --> Unable to connect to the database
ERROR - 2016-08-02 14:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:48:03 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'root'@'localhost' (using password: NO) /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:48:03 --> Unable to connect to the database
ERROR - 2016-08-02 14:48:03 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2016-08-02 14:48:03 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2016-08-02 14:48:03 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_result.php 37
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 87
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 88
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 89
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 90
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 91
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 98
ERROR - 2016-08-02 14:48:03 --> Severity: Notice  --> Trying to get property of non-object /home/vsgappshoppee/public_html/octobell/admin/sma/modules/auth/libraries/Ion_auth.php 99
ERROR - 2016-08-02 14:55:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 14:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:55:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 14:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:56:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 14:56:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 14:56:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 14:56:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:04:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:04:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:04:28 --> Could not find the language line "comment"
ERROR - 2016-08-02 16:04:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:04:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:04:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-02 16:04:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:04:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:04:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:04:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:05:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:05:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:05:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:05:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:52 --> The path to the image is not correct.
ERROR - 2016-08-02 16:06:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-02 16:06:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:06:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:06:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:07:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:07:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:07:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:07:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:07:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:07:49 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:08:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:19:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:19:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:19:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:19:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:19:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:20:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:20:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:20:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:20:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:20:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:20:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:21:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:21:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:23:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:23:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:23:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:23:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:23:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:23:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:23:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:24:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:24:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:24:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:24:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:24:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:24:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:24:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:28:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:28:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:28:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:28:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:28:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:28:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:30:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:30:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:30:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:30:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:30:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:30:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:32:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:32:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:32:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:32:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:32:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:32:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:32:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:33:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:33:09 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:33:09 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:33:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:33:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:33:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:33:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:34:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:34:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:34:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:34:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:34:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:35:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:35:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:35:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:35:34 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/view_image.php 5
ERROR - 2016-08-02 16:35:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:35:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:35:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:35:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:35:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:35:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 16:35:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 322
ERROR - 2016-08-02 16:36:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:36:06 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-02 16:36:06 --> You did not select a file to upload.
ERROR - 2016-08-02 16:36:06 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 729
ERROR - 2016-08-02 16:36:06 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 730
ERROR - 2016-08-02 16:36:06 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 731
ERROR - 2016-08-02 16:36:06 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 16:36:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:36:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:36:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:36:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:36:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:36:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:36:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:36:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:36:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:36:41 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:36:41 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:39:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:41:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:41:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:41:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:41:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:41:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:42:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:42:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:42:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:42:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:42:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:43:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:43:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:43:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:43:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:43:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:43:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:45:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:47:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:47:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:47:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:47:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:47:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:49:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:49:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:49:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:49:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:49:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:50:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:52:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:52:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:52:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:52:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:52:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:52:15 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:52:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:52:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:52:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:52:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:52:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:53:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:53:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:53:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:53:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:53:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:53:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:54:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:56:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:56:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:56:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:56:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:56:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:56:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:57:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 16:57:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:57:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 16:57:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:57:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 16:59:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 16:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:00:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:00:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:00:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:01:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:01:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:01:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:01:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:01:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:01:39 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:01:39 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:01:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 17:02:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:02:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:50 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-02 17:02:50 --> You did not select a file to upload.
ERROR - 2016-08-02 17:02:50 --> You did not select a file to upload.
ERROR - 2016-08-02 17:02:50 --> You did not select a file to upload.
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 729
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 730
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Undefined offset: 3 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 731
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 17:02:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:02:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:02:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:02:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:05:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:06:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:06:50 --> You did not select a file to upload.
ERROR - 2016-08-02 17:06:50 --> You did not select a file to upload.
ERROR - 2016-08-02 17:06:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:06:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:06:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:06:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:06:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:07:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:07:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:07:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:07:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:07:26 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:07:26 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:07:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 17:08:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:08:26 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-02 17:08:26 --> You did not select a file to upload.
ERROR - 2016-08-02 17:08:26 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 17:08:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:08:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:08:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:08:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:08:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:08:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:08:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:08:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:08:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:08:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:08:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:12:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:13:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:13:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:13:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:13:41 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:13:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:14:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:14:03 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:14:03 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:14:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:14:03 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:20:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:21:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:21:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:21:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:21:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:21:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:22:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:22:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:22:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:22:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:22:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:23:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:23:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:25:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:25:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:25:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:25:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:25:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:25:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:25:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:25:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:25:23 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:25:23 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:28:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:30:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:30:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:30:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:30:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:30:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:30:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:33:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:33:08 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:33:08 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:34:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:34:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:34:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:34:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:34:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:34:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:34:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:38:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:38:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:38:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:38:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:38:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:38:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:38:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:41:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:41:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:41:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:41:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:41:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:43:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:43:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:43:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:43:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:43:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:43:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:43:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:44:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:44:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:44:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:44:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:44:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:44:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:45:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:45:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:45:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:45:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:45:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:51:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:51:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:51:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:51:32 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:51:32 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:52:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:52:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:55:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:55:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:55:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:55:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:55:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:55:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:55:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:55:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:55:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:55:59 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:56:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:58:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:58:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:58:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:58:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:58:38 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:58:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:59:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 17:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 17:59:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:59:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 17:59:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 17:59:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:00:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:01:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:01:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:01:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:01:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:01:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:07:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:07:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:07:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:07:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:07:50 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:07:50 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:08:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:11:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:11:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:11:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:11:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:11:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:18:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:18:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:18:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:18:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:18:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:20:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:20:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:21:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:21:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:21:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:21:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:21:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:23:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:23:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:23:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:23:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:23:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:23:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 18:23:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:23:55 --> You did not select a file to upload.
ERROR - 2016-08-02 18:23:56 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 18:23:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:23:56 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:23:56 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:23:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:24:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:24:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:24:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:24:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:24:32 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:24:32 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 18:24:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:24:51 --> You did not select a file to upload.
ERROR - 2016-08-02 18:24:51 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 18:24:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:24:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:24:51 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:24:51 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:25:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:25:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:25:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:25:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:25:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:27:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:27:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:29:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:29:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:29:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:29:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:29:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:29:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:29:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:32:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:32:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:32:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:32:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:32:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:32:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:32:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 18:33:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:33:13 --> You did not select a file to upload.
ERROR - 2016-08-02 18:33:13 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 18:33:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:33:13 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:33:13 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:33:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:34:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:34:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:34:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:34:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:34:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:34:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-02 18:34:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-02 18:34:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:34:26 --> You did not select a file to upload.
ERROR - 2016-08-02 18:34:26 --> You did not select a file to upload.
ERROR - 2016-08-02 18:34:26 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-02 18:34:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:34:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:34:27 --> Could not find the language line "list_service_request"
ERROR - 2016-08-02 18:34:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:35:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-02 18:35:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-02 18:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
