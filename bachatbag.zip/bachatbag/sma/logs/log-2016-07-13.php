<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-13 09:57:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 09:57:25 --> 404 Page Not Found --> 
ERROR - 2016-07-13 09:57:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 09:57:59 --> 404 Page Not Found --> 
ERROR - 2016-07-13 09:58:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 09:58:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 09:58:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 09:58:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 10:04:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 10:04:05 --> 404 Page Not Found --> 
ERROR - 2016-07-13 10:20:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 10:20:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 10:20:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 10:20:58 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:29:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:29:13 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:32:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:32:38 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:32:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:32:58 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:32:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:32:59 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:33:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:33:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:34:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:34:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:35:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:35:32 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:35:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:35:33 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:36:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:36:31 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:38:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:38:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:38:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:38:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:39:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:39:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:39:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:39:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:39:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:39:46 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:40:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:40:39 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:40:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:40:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:41:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:41:07 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:53:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:54 --> Could not find the language line "comment"
ERROR - 2016-07-13 11:53:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:53:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:53:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 11:53:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:53:58 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:54:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:54:52 --> The path to the image is not correct.
ERROR - 2016-07-13 11:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-13 11:54:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:54:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:54:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:54:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:54:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:54:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:56:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:56:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 11:56:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 11:56:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 11:56:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 11:56:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 12:27:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:27:33 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:27:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:27:33 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:29:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:29:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:29:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:29:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:30:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:30:09 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:30:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:30:09 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:30:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:30:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:30:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:30:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:31:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:31:02 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:31:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:31:26 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:31:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:31:26 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:34:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:34:03 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:07 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:26 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:57 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:35:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:35:58 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:36:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:36:40 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:37:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:37:46 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:37:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:37:47 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:38:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:38:53 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:38:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:38:53 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:40:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:40:12 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:40:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:40:12 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:40:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:40:46 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:46:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:46:28 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:46:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:46:39 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:47:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:47:34 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:47:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:47:34 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:47:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:47:49 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:49:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:49:00 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:49:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:49:00 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:49:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:49:37 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:49:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:49:37 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:50:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:50:17 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:50:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:50:17 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:57:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:57:11 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:57:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:57:11 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:57:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:57:22 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:57:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:57:22 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:57:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:57:52 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:58:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:58:17 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:59:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:59:05 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:59:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:59:05 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:59:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:59:29 --> 404 Page Not Found --> 
ERROR - 2016-07-13 12:59:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 12:59:29 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:04 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:04 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:55 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:00:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:00:55 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:01:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:01:04 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:01:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:01:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:01:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:01:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:02:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:02:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:02:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:04:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:04:08 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:04:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:04:08 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:04:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:04:41 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:04:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:04:59 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:05:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:05:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:06:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:06:38 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:06:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:06:38 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:07:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:07:28 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:07:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:07:28 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:08:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:08:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:08:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:08:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:09:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:09:57 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:10:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:10:49 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:10:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:10:49 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:11:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:11:23 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:11:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:11:23 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:12:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:12:09 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:12:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:12:09 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:14:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:14:00 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:14:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:14:00 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:15:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:15:25 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:15:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:15:25 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:16:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:16:17 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:18:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:18:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:18:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:18:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:18:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:18:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:18:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:18:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:19:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:19:05 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:19:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:19:56 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:20:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:20:15 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:20:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:20:15 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:21:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:21:43 --> 404 Page Not Found --> 
ERROR - 2016-07-13 13:23:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 13:23:31 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:29:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:29:30 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:29:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:29:30 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:30:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:30:20 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:31:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:31:46 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:32:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:32:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:32:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:32:25 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:32:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:32:26 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:33:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:33:04 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:33:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:33:04 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:33:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:33:44 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:53:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:53:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:53:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:58:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:58:18 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:58:18 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:58:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:58:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:58:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:58:52 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:58:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:59:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:59:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:59:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:59:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:59:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:59:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 14:59:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 14:59:29 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:59:29 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 14:59:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 14:59:47 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:00:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:00:18 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:00:18 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:00:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 15:00:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 15:04:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:04:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:04:54 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:04:54 --> Could not find the language line "select_user_role"
ERROR - 2016-07-13 15:05:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:38 --> Could not find the language line "tin_number"
ERROR - 2016-07-13 15:05:38 --> Could not find the language line "dl_number"
ERROR - 2016-07-13 15:05:38 --> Could not find the language line "timings"
ERROR - 2016-07-13 15:05:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:05:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:05:42 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:42 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:05:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:46 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:05:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:06:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:06:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:06:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:06:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:06:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:06:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:06:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:06:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:06:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:07:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:07:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:07:20 --> Could not find the language line "comment"
ERROR - 2016-07-13 15:07:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 15:07:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:09:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:09:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:53 --> Could not find the language line "comment"
ERROR - 2016-07-13 15:09:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:09:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:09:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 15:09:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:09:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:09:57 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:09:57 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:10:48 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:48 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:10:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:11:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:11:09 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:11:09 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:11:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:11:53 --> The path to the image is not correct.
ERROR - 2016-07-13 15:11:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-13 15:11:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:11:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:11:53 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:11:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:11:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:53 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:11:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:11:53 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:12:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:12:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:12:38 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:13:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:13:37 --> The path to the image is not correct.
ERROR - 2016-07-13 15:13:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-07-13 15:13:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:13:37 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:13:37 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 15:13:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:13:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:37 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:13:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:37 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:13:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:48 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:13:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:48 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:13:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:52 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:13:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:13:52 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:31:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:31:16 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:31:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:31:34 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:31:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:31:34 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:01 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:20 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:22 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:22 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:32:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:32:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:39:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:02 --> 404 Page Not Found --> 
ERROR - 2016-07-13 15:39:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:39:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:39:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:39:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:39:37 --> Could not find the language line "comment"
ERROR - 2016-07-13 15:39:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 15:39:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:39:50 --> Could not find the language line "comment"
ERROR - 2016-07-13 15:39:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 15:42:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:42:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 15:58:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 15:58:18 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:07:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:07:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:08:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:08:22 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:09:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:09:21 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:09:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:09:59 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:11:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:11:50 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:12:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:12:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:14:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:14:13 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:14:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:14:30 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:14:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:14:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:14:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:14:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:14:47 --> Could not find the language line "comment"
ERROR - 2016-07-13 16:14:47 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:14:47 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:14:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 16:15:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:15:02 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:02 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:02 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:15:02 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:15:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:15:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:03 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:15:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:15:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:15:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:15:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:15:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:15:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-07-13 16:15:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-07-13 16:15:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:15:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:04 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:16:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:16:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 200
ERROR - 2016-07-13 16:16:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-07-13 16:16:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-07-13 16:16:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:06 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:16:06 --> Could not find the language line "pr_category_tip"
ERROR - 2016-07-13 16:16:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 254
ERROR - 2016-07-13 16:16:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\products\views\edit.php 320
ERROR - 2016-07-13 16:16:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:27 --> You did not select a file to upload.
ERROR - 2016-07-13 16:16:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octobel_old\admin\sma\modules\products\controllers\products.php 730
ERROR - 2016-07-13 16:16:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:27 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 16:16:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 16:16:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:32 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:16:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:16:32 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:18:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:18:49 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:20:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:20:14 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:21:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:21:30 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:24:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:24:09 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:24:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:24:26 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:26:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:26:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:26:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:26:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:27:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:27:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:27:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:27:45 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:28:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:28:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:28:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:28:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:42:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:42:08 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:42:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:42:08 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:42:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:42:46 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:43:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:43:11 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:44:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:44:35 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:45:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:45:31 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:45:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:45:31 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:45:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:45:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:47:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:47:27 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:48:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:48:42 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:49:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:49:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:49:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:49:06 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:50:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:50:41 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:53:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:53:24 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:53:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:53:52 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:55:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:55:29 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:57:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:57:10 --> 404 Page Not Found --> 
ERROR - 2016-07-13 16:58:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 16:58:19 --> 404 Page Not Found --> 
ERROR - 2016-07-13 17:03:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:03:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:03:16 --> Could not find the language line "comment"
ERROR - 2016-07-13 17:03:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:03:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:03:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-13 17:03:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:03:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:03:24 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:03:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:03:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:03:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:03:30 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:12 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:12 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:20 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:25 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:25 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:37 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:37 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:04:43 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:43 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:04:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:01 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:10 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:10 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:16 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:05:22 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:22 --> Could not find the language line "list_service_request"
ERROR - 2016-07-13 17:05:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:20:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:20:17 --> 404 Page Not Found --> 
ERROR - 2016-07-13 17:51:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-13 17:59:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:59:49 --> 404 Page Not Found --> 
ERROR - 2016-07-13 17:59:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 17:59:54 --> 404 Page Not Found --> 
ERROR - 2016-07-13 18:01:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 18:01:31 --> 404 Page Not Found --> 
ERROR - 2016-07-13 18:02:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 18:02:13 --> 404 Page Not Found --> 
ERROR - 2016-07-13 18:06:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 18:06:41 --> 404 Page Not Found --> 
ERROR - 2016-07-13 18:07:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-13 18:07:12 --> 404 Page Not Found --> 
