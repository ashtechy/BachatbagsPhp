<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-05 10:05:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:05:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:05:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:05:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:05:56 --> Could not find the language line "comment"
ERROR - 2016-08-05 10:05:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 10:07:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:08:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:08:48 --> Could not find the language line "select_user_role"
ERROR - 2016-08-05 10:09:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 10:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 10:09:42 --> Could not find the language line "comment"
ERROR - 2016-08-05 10:09:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 11:08:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:08:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:09:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:09:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:09:20 --> Could not find the language line "comment"
ERROR - 2016-08-05 11:09:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 11:09:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:09:27 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 11:09:27 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 11:11:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:12:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 458
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 459
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 460
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 461
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 462
ERROR - 2016-08-05 11:15:09 --> You did not select a file to upload.
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 476
ERROR - 2016-08-05 11:15:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:15:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 11:15:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 11:16:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:16:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:18:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 458
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 459
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 460
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 461
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 462
ERROR - 2016-08-05 11:18:52 --> You did not select a file to upload.
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 475
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Undefined offset: 1 /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 476
ERROR - 2016-08-05 11:18:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:18:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 11:18:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 11:18:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:21:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 12:21:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 12:21:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-05 12:21:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 12:22:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 12:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:10 --> Could not find the language line "comment"
ERROR - 2016-08-05 13:10:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 13:10:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-05 13:10:18 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-05 13:10:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:22 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:10:58 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-05 13:10:58 --> Could not find the language line "no_suggestions"
ERROR - 2016-08-05 13:12:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 13:12:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 13:12:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:23:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:23:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:36:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:36:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:36:00 --> Could not find the language line "comment"
ERROR - 2016-08-05 15:36:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 15:36:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:38 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:36:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:37:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:37:21 --> Could not find the language line "comment"
ERROR - 2016-08-05 15:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 15:37:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:37:56 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 15:37:56 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-05 15:43:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:48:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:48:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:48:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:48:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:48:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:48:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:48:20 --> Could not find the language line "comment"
ERROR - 2016-08-05 15:48:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-05 15:50:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-05 15:50:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-05 15:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
