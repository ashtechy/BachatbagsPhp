<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-11 09:49:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 09:49:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:19:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:19:46 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:20:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:20:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:20:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:20:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:21:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:21:06 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:21:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:21:06 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:22:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:22:01 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:27:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:27:08 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:29:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:29:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:30:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:30:18 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:30:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:30:25 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:30:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:30:47 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:31:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:31:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:32:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:32:02 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:32:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:32:38 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:34:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:34:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:36:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:36:21 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:36:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:36:21 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:36:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:36:39 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:36:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:36:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:37:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:37:04 --> 404 Page Not Found --> 
ERROR - 2016-07-11 10:37:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 10:37:10 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:37:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:45 --> Could not find the language line "comment"
ERROR - 2016-07-11 11:37:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:37:45 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobel_old\admin\sma\modules\home\views\content.php 188
ERROR - 2016-07-11 11:37:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:37:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:37:50 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:38:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:38:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:38:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:38:17 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 11:38:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 11:39:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:39:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:39:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:39:48 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:41:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:41:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:41:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:41:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:49:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:49:22 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:49:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:49:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:49:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:49:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:50:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:50:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:50:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:50:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:51:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:51:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:52:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:52:29 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:54:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:54:02 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:54:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:54:21 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:56:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:56:22 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:56:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:56:22 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:01 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:01 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:33 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:33 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:57:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:57:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:11 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:11 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:42 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:58:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:58:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:59:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:59:02 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:59:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:59:38 --> 404 Page Not Found --> 
ERROR - 2016-07-11 11:59:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 11:59:38 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:00:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:00:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:02:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:02:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:02:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:02:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:03:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:03:05 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:03:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:03:05 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:03:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:03:30 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:03:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:03:30 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:03:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:03:59 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:04:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:04:55 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:04:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:04:55 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:05:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:05:45 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:05:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:05:45 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:06:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:06:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:06:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:06:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:07:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:07:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:07:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:07:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:08:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:08:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:08:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:08:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:08:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:08:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:08:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:08:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:33 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:33 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:52 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:09:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:09:52 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:10:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:10:03 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:10:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:10:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:10:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:10:50 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:10:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:10:58 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:10:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:10:58 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:08 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:08 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:25 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:25 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:30 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:30 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:11:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:11:47 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:12:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:12:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:12:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:12:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:12:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:12:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:13:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:13:01 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:13:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:13:01 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:13:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:13:42 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:13:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:13:42 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:14:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:14:26 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:15:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:15:47 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:16:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:16:16 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:16:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:16:16 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:17:07 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:17:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:17:07 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:18:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:18:25 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:18:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:18:25 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:19:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:19:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:20:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:20:14 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:20:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:20:14 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:20:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:20:28 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:20:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:20:28 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:21:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:21:03 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:21:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:21:28 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:21:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:21:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:21:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:21:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:22:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:22:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:22:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:22:49 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:23:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:23:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:23:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:23:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:24:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:24:04 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:24:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:24:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:24:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:24:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:25:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:25:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:25:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:25:24 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:27:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:27:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:27:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:27:54 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:28:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:28:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:28:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:28:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:28:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:28:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:28:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:28:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:29:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:29:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 12:29:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 12:29:55 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 12:29:55 --> Could not find the language line "list_service_request"
ERROR - 2016-07-11 12:29:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobel_old\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-11 12:29:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:29:55 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:29:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:29:55 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:31:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:31:22 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:32:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:32:16 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:34:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:34:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:35:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:35:20 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:37:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:37:28 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:37:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:37:28 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:38:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:38:07 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:38:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:38:07 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:38:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:38:11 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:38:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:38:39 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:39:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:39:02 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:39:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:39:42 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:39:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:39:42 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:40:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:40:08 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:40:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:40:08 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:40:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:40:37 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:40:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:40:37 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:40:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:40:48 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:41:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:41:27 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:41:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:41:27 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:42:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:42:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:42:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:42:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:43:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:43:59 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:43:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:43:59 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:44:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:44:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:44:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:44:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:44:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:44:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:44:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:44:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:49:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:49:35 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:49:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:49:35 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:51:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:51:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:51:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:51:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:53:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:53:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:53:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:53:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:53:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:53:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:54:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:54:43 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:54:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:54:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:54:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:54:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:54:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:54:57 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:55:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:55:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 12:55:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 12:55:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:33:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:33:09 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:33:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:33:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:34:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:34:10 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:34:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:34:26 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:34:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:34:26 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:35:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:35:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:35:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:35:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:36:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:36:05 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:36:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:36:05 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:36:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:36:47 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:37:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:37:12 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:51:33 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:51:33 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:52:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:52:04 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:52:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:52:05 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:52:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:52:27 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:52:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:52:27 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:53:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:53:58 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:54:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:54:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:54:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:54:31 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:55:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:55:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:56:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:56:13 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:56:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:56:13 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:56:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:56:53 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:56:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:56:53 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:57:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:57:02 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:58:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:58:06 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:58:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:58:39 --> 404 Page Not Found --> 
ERROR - 2016-07-11 14:59:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 14:59:23 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:00:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:00:24 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:00:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:00:44 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:01:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:01:18 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:01:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:01:18 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:03:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:03:34 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:03:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:03:35 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:03:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:03:56 --> 404 Page Not Found --> 
ERROR - 2016-07-11 15:04:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-11 15:04:25 --> 404 Page Not Found --> 
