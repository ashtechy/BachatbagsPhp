<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-15 12:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:26 --> Could not find the language line "comment"
ERROR - 2016-06-15 12:10:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:10:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:10:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:51 --> Could not find the language line "comment"
ERROR - 2016-06-15 12:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:11:09 --> Could not find the language line "comment"
ERROR - 2016-06-15 12:11:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:11:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:11:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:11:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:11:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 12:11:31 --> Could not find the language line "specification"
ERROR - 2016-06-15 12:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:12:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:12:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:12:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 12:12:07 --> Could not find the language line "specification"
ERROR - 2016-06-15 12:12:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:12:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:12:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:12:22 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 12:12:22 --> Could not find the language line "specification"
ERROR - 2016-06-15 12:14:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:14:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:14:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:14:14 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 12:14:14 --> Could not find the language line "specification"
ERROR - 2016-06-15 12:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:16:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:16:05 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 462
ERROR - 2016-06-15 12:16:05 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 463
ERROR - 2016-06-15 12:16:05 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 464
ERROR - 2016-06-15 12:16:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 470
ERROR - 2016-06-15 12:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:16:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:16:06 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:17:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:17:05 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 12:19:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:19:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 12:19:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 12:19:38 --> Could not find the language line "specification"
ERROR - 2016-06-15 13:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 13:19:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 13:19:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 13:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 13:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 13:29:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 13:29:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 13:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:20:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:20:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:20:33 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:20:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:20:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:20:34 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:20:34 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:20:34 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:20:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:21:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 462
ERROR - 2016-06-15 15:21:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 463
ERROR - 2016-06-15 15:21:26 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 464
ERROR - 2016-06-15 15:21:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 470
ERROR - 2016-06-15 15:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:21:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:21:26 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:21:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:21:31 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:21:31 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:22:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:22:25 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:22:25 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:22:25 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:23:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:23:51 --> Severity: Notice  --> Undefined variable: data1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 686
ERROR - 2016-06-15 15:23:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:23:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:23:51 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:23:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:23:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:23:57 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:23:57 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:23:57 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:27:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:27:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:27:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:27:09 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:27:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:27:45 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:30:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:30:28 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:31:24 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:31:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:31:48 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:32:38 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:33:04 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 281
ERROR - 2016-06-15 15:33:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 673
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 674
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 675
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 683
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 684
ERROR - 2016-06-15 15:33:38 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 281
ERROR - 2016-06-15 15:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:34:30 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 676
ERROR - 2016-06-15 15:34:30 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 677
ERROR - 2016-06-15 15:34:30 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 678
ERROR - 2016-06-15 15:34:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:34:30 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 281
ERROR - 2016-06-15 15:35:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:35:06 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 676
ERROR - 2016-06-15 15:35:06 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 677
ERROR - 2016-06-15 15:35:06 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 678
ERROR - 2016-06-15 15:35:06 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:35:06 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:35:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:35:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:35:37 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:35:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:35:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:43 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:35:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:35:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:35:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:35:47 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:36:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:36:12 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:36:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:36:12 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:36:43 --> You did not select a file to upload.
ERROR - 2016-06-15 15:36:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:36:43 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:37:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:37:09 --> You did not select a file to upload.
ERROR - 2016-06-15 15:37:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:37:09 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:37:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:37:29 --> You did not select a file to upload.
ERROR - 2016-06-15 15:37:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:37:29 --> Severity: Notice  --> Undefined index: product_name C:\xampp\htdocs\octbell\sma\modules\products\models\products_model.php 280
ERROR - 2016-06-15 15:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:38:02 --> You did not select a file to upload.
ERROR - 2016-06-15 15:38:02 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:38:24 --> You did not select a file to upload.
ERROR - 2016-06-15 15:38:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 687
ERROR - 2016-06-15 15:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:39:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:39:44 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:39:44 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:39:44 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:55:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:55:08 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:55:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:55:09 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:56:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:56:27 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:56:27 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 15:56:27 --> Could not find the language line "specification"
ERROR - 2016-06-15 15:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 15:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 15:57:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:18:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:18:38 --> Severity: Notice  --> Undefined variable: product_feature C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:18:38 --> Severity: Notice  --> Undefined variable: product_feature_specification C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:18:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:18:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:45 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:18:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:48 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:18:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:18:48 --> Severity: Notice  --> Undefined variable: product_feature C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:18:48 --> Severity: Notice  --> Undefined variable: product_feature_specification C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:21:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:21:16 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:21:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:21:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:22:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:22:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:22:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:22:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:22:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:24:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:24:04 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:24:04 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:24:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:24:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:24:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:24:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:24:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:24:37 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:25:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:25:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:25:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
ERROR - 2016-06-15 18:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-15 18:31:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:31:29 --> Could not find the language line "list_service_request"
ERROR - 2016-06-15 18:31:29 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-15 18:31:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 243
ERROR - 2016-06-15 18:31:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octbell\sma\modules\products\views\edit.php 309
