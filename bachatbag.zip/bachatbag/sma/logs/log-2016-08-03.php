<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-03 10:01:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:20 --> Could not find the language line "comment"
ERROR - 2016-08-03 10:01:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-03 10:01:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:40 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:40 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:01:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:52 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:01:52 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 10:01:52 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 10:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/views/edit.php 200
ERROR - 2016-08-03 10:02:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:02:18 --> You did not select a file to upload.
ERROR - 2016-08-03 10:02:18 --> Severity: Notice  --> Undefined variable: photo /home/vsgappshoppee/public_html/octobell/admin/sma/modules/products/controllers/products.php 772
ERROR - 2016-08-03 10:02:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:02:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:02:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:02:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:56:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 10:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 10:56:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:56:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 10:56:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 10:56:20 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 11:01:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:01:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:02:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:02:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:02:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:02:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:02:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:23:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:23:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:23:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:23:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 11:23:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 11:24:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:24:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:27:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:27:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:27:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:27:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:27:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 11:27:04 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 11:27:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:27:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:27:31 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:27:31 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:27:31 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:27:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:29:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:29:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:31:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:31:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:31:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:32:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:32:17 --> The path to the image is not correct.
ERROR - 2016-08-03 11:32:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-03 11:32:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:32:17 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:32:17 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:32:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:32:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:32:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:32:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:34:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:34:18 --> The path to the image is not correct.
ERROR - 2016-08-03 11:34:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-03 11:34:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:34:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:34:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:34:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:35:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:35:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:35:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:35:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:35:49 --> The path to the image is not correct.
ERROR - 2016-08-03 11:35:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-03 11:35:49 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:35:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:35:49 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:35:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:35:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:36:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:36:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:36:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:37:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:37:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:37:42 --> The path to the image is not correct.
ERROR - 2016-08-03 11:37:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-03 11:37:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:37:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:37:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:37:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:38:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:38:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:38:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:38:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:38:43 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-08-03 11:38:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:38:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:38:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:39:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:39:23 --> The path to the image is not correct.
ERROR - 2016-08-03 11:39:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2016-08-03 11:39:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:39:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:39:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:39:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:40:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:40:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:40:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:04 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:43:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:43:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:15 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:30 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:30 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:44:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:44:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:45:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:45:17 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:45:17 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:45:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:45:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:45:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:45:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:45:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:45:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:47:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:47:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:47:26 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:47:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:47:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:47:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:50 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:50 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:48:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:48:59 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:49:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:49:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:49:33 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:49:33 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:49:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:49:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:49:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:49:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:49:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:50:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:50:25 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:50:25 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:50:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:50:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:50:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:50:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:50:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:08 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:08 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:29 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:51:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:51:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:55:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:55:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:55:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:55:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:55:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:55:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:55:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:55:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:56:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:56:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:56:53 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:57:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:57:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:57:06 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:57:06 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:57:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:57:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:58:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:58:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:58:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:58:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:58:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:58:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:58:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:58:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:59:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:59:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:59:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:19 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:59:19 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:59:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 11:59:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 11:59:56 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 11:59:56 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:08 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:00:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:01:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:01:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:01:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:01:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:01:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:01:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:01:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:01:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:02:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:02:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:02:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:02:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:02:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:02:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:02:32 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:02:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:03:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:03:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:03:34 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:03:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:03:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:03:43 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:04:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:04:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:04:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:04:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:04:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:04:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:04:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:05:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:05:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:05:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:05:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:05:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:05:01 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:05:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:05:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:02 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:02 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:42 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:42 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:55 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:55 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:06:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:06:57 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:07:44 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:07:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:07:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:07:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 12:07:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 12:56:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 12:56:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:01:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:02:00 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:02:00 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:02:00 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:02:00 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:09:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:13:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:13:23 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:13:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:13:23 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:13:24 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:13:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:13:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:13:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:13:48 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:13:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:13:48 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:14:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:14:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:16:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:16:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:16:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:16:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:16:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:18:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:18:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:18:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:18:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:18:10 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:18:32 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:18:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:20:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:20:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:20:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:20:20 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:20:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:22:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:22:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:22:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:22:07 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:22:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:22:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:22:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:23:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:23:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:23:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:23:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:23:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:23:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:23:48 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:29:05 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:29:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:29:05 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:29:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:29:05 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:29:33 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:31:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:31:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:31:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:31:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:31:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:31:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:31:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:32:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:32:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:32:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:32:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:38:29 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:38:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:40:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:40:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:40:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:40:14 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:40:14 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:41:54 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:41:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:41:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:41:54 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:41:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:41:54 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:42:26 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:43:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:43:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:43:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:43:58 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:43:58 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:50:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:50:13 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:50:13 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:50:13 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:50:13 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:51:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:52:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:52:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:52:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:52:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:52:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:54:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:54:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:54:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:54:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:54:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:55:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:56:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:56:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:56:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:56:37 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:56:37 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:57:47 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 15:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 15:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:57:47 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 15:57:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 15:57:47 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:00:36 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:01:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:01:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:01:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:01:10 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:01:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:04 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:12 --> Could not find the language line "comment"
ERROR - 2016-08-03 16:03:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:03:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:03:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/octobell/admin/sma/modules/home/views/content.php 188
ERROR - 2016-08-03 16:03:16 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:03:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:03:16 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:03:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:03:16 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:03:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:04:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:04:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:12:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:12:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:12:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:12:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:12:39 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:12:39 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:13:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:15:20 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:15:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:15:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:15:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:15:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:16:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:16:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:16:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:16:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:16:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:16:12 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:17:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:19:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:19:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:19:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:19:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:19:19 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:19:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:23:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:23:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:23:11 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:23:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:23:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:28:59 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:28:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:29:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:29:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:29:12 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:29:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:29:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:29:12 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:29:13 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:29:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:29:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:29:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:29:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:29:45 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:30:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:30:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:31:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:31:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:31:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:31:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:31:40 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:32:28 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:32:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:32:28 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:32:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:32:28 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:33:11 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:33:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:35:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:35:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:35:09 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:35:09 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:35:09 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:35:21 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:35:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:35:21 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:35:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:35:21 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 16:35:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:37:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:37:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 16:37:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:37:39 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 16:37:39 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 16:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:42:18 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:42:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:42:18 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:42:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 17:42:18 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 17:42:41 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:44:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:44:45 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:44:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:44:45 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:44:46 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:45:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:45:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:45:35 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:45:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 17:45:35 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-03 17:47:27 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:48:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:48:01 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-03 17:48:02 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:48:02 --> Could not find the language line "list_service_request"
ERROR - 2016-08-03 17:48:02 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/octobell/admin/system/core/Common.php 257
ERROR - 2016-08-03 17:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/octobell/admin/system/database/drivers/mysql/mysql_driver.php 91
