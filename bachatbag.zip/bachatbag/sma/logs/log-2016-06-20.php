<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-20 11:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-20 11:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-20 11:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-20 11:11:37 --> Could not find the language line "comment"
ERROR - 2016-06-20 11:11:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-20 11:11:37 --> Could not find the language line "list_service_request"
ERROR - 2016-06-20 11:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-20 11:11:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-20 11:11:41 --> Could not find the language line "list_service_request"
ERROR - 2016-06-20 11:11:41 --> Could not find the language line "pr_category_tip"
