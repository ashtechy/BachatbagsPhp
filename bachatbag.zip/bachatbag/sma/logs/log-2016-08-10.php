<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-10 12:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 12:24:20 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 12:24:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 12:24:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 12:24:33 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 18:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 18:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-10 18:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
