<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-09 10:20:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:20:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:20:27 --> Could not find the language line "comment"
ERROR - 2016-08-09 10:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\octobell\admin\sma\modules\home\views\content.php 188
ERROR - 2016-08-09 10:20:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:20:32 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:20:32 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:20:32 --> Could not find the language line "select_user_role"
ERROR - 2016-08-09 10:21:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:25:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:25:31 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:31 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:31 --> Could not find the language line "select_user_role"
ERROR - 2016-08-09 10:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:25:32 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:32 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:32 --> Could not find the language line "select_user_role"
ERROR - 2016-08-09 10:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:25:36 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:36 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\octobell\admin\sma\modules\auth\controllers\auth.php 445
ERROR - 2016-08-09 10:25:36 --> Could not find the language line "select_user_role"
ERROR - 2016-08-09 10:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-08-09 10:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octobell\admin\system\database\drivers\mysql\mysql_driver.php 91
