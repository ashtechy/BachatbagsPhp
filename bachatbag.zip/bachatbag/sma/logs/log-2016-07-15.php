<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-15 16:17:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:17:41 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:18:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:18:40 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:51:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:51:20 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:51:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:51:50 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:51:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:51:58 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:52:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:52:48 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:52:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:52:51 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:53:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:53:27 --> 404 Page Not Found --> 
ERROR - 2016-07-15 16:53:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 16:53:31 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:16:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:16:17 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:17:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:17:12 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:18:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:18:53 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:19:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:19:48 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:20:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:20:31 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:21:04 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:21:04 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:21:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:21:41 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:22:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:22:29 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:23:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:23:16 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:23:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:23:20 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:01 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:05 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:07 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:10 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:14 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:16 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:24:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:24:20 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:08 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:08 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:12 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:20 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:23 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:26 --> 404 Page Not Found --> 
ERROR - 2016-07-15 17:25:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 17:25:29 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:25:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:25:50 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:25:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:25:53 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:01 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:06 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:09 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:13 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:15 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:26 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:43 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:43 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:44 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:26:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:26:55 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:36:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:36:17 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:37:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:37:48 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:38:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:38:45 --> 404 Page Not Found --> 
ERROR - 2016-07-15 18:43:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-15 18:43:21 --> 404 Page Not Found --> 
