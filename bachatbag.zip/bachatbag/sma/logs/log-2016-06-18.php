<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-18 10:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 10:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 10:31:23 --> Could not find the language line "comment"
ERROR - 2016-06-18 10:31:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 10:31:23 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 10:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 10:52:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 10:52:09 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 10:52:09 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 12:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:23:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:23:01 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:23:01 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 12:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:25:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:25:50 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:25:50 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 12:25:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:25:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:25:58 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:25:58 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 12:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 12:26:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:26:30 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 12:26:30 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 12:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 13:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 13:37:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 13:37:38 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 13:37:38 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-18 15:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-18 15:02:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 15:02:28 --> Could not find the language line "list_service_request"
ERROR - 2016-06-18 15:02:28 --> Could not find the language line "pr_category_tip"
