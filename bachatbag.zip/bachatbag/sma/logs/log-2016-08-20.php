<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-08-20 15:28:34 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:28:35 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:28:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:28:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:28:53 --> Could not find the language line "comment"
ERROR - 2016-08-20 15:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/vsgappshoppee/public_html/bachatbag/sma/modules/home/views/content.php 188
ERROR - 2016-08-20 15:29:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:29:07 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:29:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:36:43 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:37:00 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 15:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 15:37:00 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-20 15:37:00 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-20 17:34:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:35:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:35:10 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:35:10 --> Could not find the language line "ratings_details"
ERROR - 2016-08-20 17:36:15 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:36:17 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:36:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:36:25 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:36:25 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_rating.php 5
ERROR - 2016-08-20 17:40:52 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:40:52 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_rating.php 5
ERROR - 2016-08-20 17:40:56 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:40:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:40:56 --> Severity: Notice  --> Undefined variable: page_title /home/vsgappshoppee/public_html/bachatbag/sma/modules/products/views/view_rating.php 5
ERROR - 2016-08-20 17:48:53 --> Severity: Notice  --> Only variable references should be returned by reference /home/vsgappshoppee/public_html/bachatbag/system/core/Common.php 257
ERROR - 2016-08-20 17:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/vsgappshoppee/public_html/bachatbag/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-20 17:48:53 --> Could not find the language line "pr_category_tip"
ERROR - 2016-08-20 17:48:53 --> Could not find the language line "pr_category_tip"
