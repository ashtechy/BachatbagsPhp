<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-14 09:59:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 09:59:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:00:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:00:07 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:00:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:00:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:02:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:02:20 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:02:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:02:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:02:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:02:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:02:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:02:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:02:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:02:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:02 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:03 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:03:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:03:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:51 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:05:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:05:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:11:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:11:58 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:12:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:12:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:12:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:12:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:20:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:20:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:21:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:21:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:51:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:51:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:51:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:51:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 10:53:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 10:53:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 11:56:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 11:56:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 11:58:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 11:58:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 11:59:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 11:59:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 11:59:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:00:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:00:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:00:21 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:00:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:00:22 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:00:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:00:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:02:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:02:05 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:02:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:02:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:02:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:02:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:02:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:02:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:02:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:02:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:03:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:03:08 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:03:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:03:22 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:06:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:06:26 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:06:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:06:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:12:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:12:32 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:13:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:13:10 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:13:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:13:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:15:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:15:01 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:15:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:15:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:16:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:16:24 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:16:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:16:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:18:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:18:14 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:18:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:18:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:30:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:30:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:38:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:38:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:39:01 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:39:01 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:45:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:45:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:45:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:45:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:46:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:46:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 12:46:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 12:46:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:17:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:17:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:18:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:18:29 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:20:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:20:02 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:20:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:20:07 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:20:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:20:08 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:21:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:21:58 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:23:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:23:14 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:24:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:24:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:25:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:25:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:25:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:25:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:26:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:26:05 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:28:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:28:24 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:28:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:28:37 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:30:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:30:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:30:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:30:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:31:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:31:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:32:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:32:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:34:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:34:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:34:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:34:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:35:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:35:10 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:35:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:35:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:35:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:35:45 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:35:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:35:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:35:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:35:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:36:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:36:57 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:37:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:37:43 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:37:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:37:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:37:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:37:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:38:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:38:16 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:38:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:38:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 13:38:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 13:38:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:00:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:00:16 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:03:08 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:03:08 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:03:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:03:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:03:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:03:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:03:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:03:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:06:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:06:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:06:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:06:36 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:07:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:07:03 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:07:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:07:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:07:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:07:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:08:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:08:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:08:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:08:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:09:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:09:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:10:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:10:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:10:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:10:45 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:12:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:12:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:13:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:13:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:17:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:17:34 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:17:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:17:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:18:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:18:06 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:18:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:18:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:25:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:25:57 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:27:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:27:26 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:32:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:32:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:34:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:34:10 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:34:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:34:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:35:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:35:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:35:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:35:26 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:36:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:36:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:37:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:37:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:38:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:38:40 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:38:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:38:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:39:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:39:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:40:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:40:07 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:40:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:40:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:40:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:40:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:41:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:41:21 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:41:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:41:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:42:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:42:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:42:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:42:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:43:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:43:34 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:47:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:47:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:47:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:47:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:49:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:49:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:49:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:49:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:49:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:49:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:49:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:49:25 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:49:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:49:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:50:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:50:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:50:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:50:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:51:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:51:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:51:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:51:21 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:51:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:51:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:51:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:51:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:52:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:52:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:52:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:52:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:52:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:52:43 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:52:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:52:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:53:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:53:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:53:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:53:35 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:53:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:53:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:54:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:54:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:55:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:55:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:55:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:55:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:56:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:56:03 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:59:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:59:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:59:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:59:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:59:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:59:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 15:59:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 15:59:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:02:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:02:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:03:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:03:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:03:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:03:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:05:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:05:36 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:05:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:05:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:06:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:06:02 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:10:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:10:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:10:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:10:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:10:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:10:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:11:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:11:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:11:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:11:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:12:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:12:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:12:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:12:57 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:13:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:13:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:13:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:13:20 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:13:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:13:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:13:29 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:13:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:15:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:15:37 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:16:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:16:14 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:17:59 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:17:59 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:18:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:18:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:19:16 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:19:16 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:19:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:19:55 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:21:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:21:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:24:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:24:05 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:24:42 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:24:42 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:25:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:25:24 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:26:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:26:21 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:26:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:26:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:28:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:28:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:28:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:28:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:29:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:29:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:30:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:30:06 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:30:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:30:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:31:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:31:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:32:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:32:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:32:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:32:18 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:33:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:33:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:33:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:33:26 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:33:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:33:35 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:35:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:35:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:36:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:36:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:37:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:37:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:38:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:38:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:38:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:38:40 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:38:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:38:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:39:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:39:36 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:39:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:39:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:40:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:40:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:40:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:40:20 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:42:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:42:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:42:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:42:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:45:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:45:34 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:47:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:47:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:47:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:47:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:52:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:52:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:54:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:54:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:55:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:55:25 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:57:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:57:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:57:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:57:18 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:57:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:57:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:57:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:57:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:58:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:58:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 16:59:07 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 16:59:07 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:03:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:03:02 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:03:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:03:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:04:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:04:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:04:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:04:23 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:05:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:05:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:05:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:05:18 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:07:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:07:20 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:10:22 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:10:22 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:10:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:10:32 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:10:52 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:10:52 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:10:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:10:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:12:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:12:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:12:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:12:51 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:21:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:21:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:24:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:24:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:24:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:24:40 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:25:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:25:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:25:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:25:37 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:26:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:26:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:28:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:28:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:28:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:28:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:29:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:29:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:30:24 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:30:24 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:31:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:31:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:31:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:31:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:31:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:31:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:33:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:33:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:35:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:35:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:35:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:35:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:37:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:37:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:37:20 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:37:20 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:37:30 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:37:30 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:38:27 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:38:27 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:38:47 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:38:47 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:39:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:39:49 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:40:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:40:03 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:40:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:40:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:40:44 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:40:44 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:43:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:43:14 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:43:19 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:43:19 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:43:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:43:50 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:43:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:43:53 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:44:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:44:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:44:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:44:10 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:44:13 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:44:13 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:44:18 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:44:18 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:47:55 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:47:55 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:47:58 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:47:58 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:03 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:03 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:05 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:11 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:11 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:15 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:15 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:35 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:35 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:48:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:48:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:49:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:49:45 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:49:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:49:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 17:49:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 17:49:51 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:00:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:00:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:00:36 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:00:36 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:00:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:00:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:01:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:01:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:01:26 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:01:26 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:01:31 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:01:31 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:01:38 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:01:38 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:01:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:01:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:17:25 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:17:25 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:17:28 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:17:28 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:17:32 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:17:32 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:17:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:17:51 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:17:57 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:17:57 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:18:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:18:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:18:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:18:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:18:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:18:43 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:18:48 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:18:48 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:19:02 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:19:02 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:19:05 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:19:05 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:19:09 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:19:09 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:19:12 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:19:12 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:06 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:06 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:10 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:10 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:14 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:14 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:17 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:21 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:21 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:34 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:34 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:39 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:39 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:43 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:43 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:54 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:54 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:20:56 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:20:56 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:21:00 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:21:00 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:37 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:37 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:40 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:40 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:41 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:41 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:45 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:45 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:46 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:46 --> 404 Page Not Found --> 
ERROR - 2016-07-14 18:22:49 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\octobel_old\admin\system\core\Common.php 257
ERROR - 2016-07-14 18:22:49 --> 404 Page Not Found --> 
