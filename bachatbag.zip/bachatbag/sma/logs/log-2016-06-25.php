<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-06-25 14:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 14:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 14:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 14:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 14:42:13 --> Could not find the language line "comment"
ERROR - 2016-06-25 14:42:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 14:42:14 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 14:44:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 14:44:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 14:44:13 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 14:44:13 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-25 15:01:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:01:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:01:11 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:01:11 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-25 15:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:05:21 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 465
ERROR - 2016-06-25 15:05:21 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 466
ERROR - 2016-06-25 15:05:21 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 467
ERROR - 2016-06-25 15:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:05:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:05:22 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:06:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:06:07 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:06:07 --> Could not find the language line "pr_category_tip"
ERROR - 2016-06-25 15:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:06:24 --> You did not select a file to upload.
ERROR - 2016-06-25 15:06:24 --> You did not select a file to upload.
ERROR - 2016-06-25 15:06:24 --> You did not select a file to upload.
ERROR - 2016-06-25 15:06:24 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 712
ERROR - 2016-06-25 15:06:24 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 713
ERROR - 2016-06-25 15:06:24 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 714
ERROR - 2016-06-25 15:06:24 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\octbell\sma\modules\products\controllers\products.php 723
ERROR - 2016-06-25 15:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 15:06:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:06:24 --> Could not find the language line "list_service_request"
ERROR - 2016-06-25 15:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-06-25 17:03:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\octbell\system\database\drivers\mysql\mysql_driver.php 91
